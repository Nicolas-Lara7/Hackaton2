import { Navigate, Outlet, useLocation } from 'react-router'
import type { Location } from 'react-router'
import { useAuth } from '../auth/AuthContext'
import { FullScreenLoader } from './StatusViews'

// En el state de la navegación guardamos a dónde quería ir el usuario.
interface FromState {
  from?: Location
}

// Rutas privadas: sin sesión → al login, recordando la ruta exacta (path + query + hash).
export function RequireAuth() {
  const { status } = useAuth()
  const location = useLocation()

  if (status === 'checking') return <FullScreenLoader text="Verificando sesión..." />
  if (status === 'anonymous') return <Navigate to="/login" replace state={{ from: location }} />
  return <Outlet />
}

// Login y registro: si ya hay sesión, volvemos a donde el usuario quería ir (o al dashboard).
export function PublicOnly() {
  const { status } = useAuth()
  const location = useLocation()

  if (status === 'checking') return <FullScreenLoader text="Verificando sesión..." />
  if (status === 'authenticated') {
    const from = (location.state as FromState | null)?.from
    const target = from ? `${from.pathname}${from.search}${from.hash}` : '/'
    return <Navigate to={target} replace />
  }
  return <Outlet />
}

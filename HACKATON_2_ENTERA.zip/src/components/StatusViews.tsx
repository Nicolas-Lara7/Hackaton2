// Vistas reutilizables para los tres estados: cargando, error (con reintento) y vacío.

export function Spinner({ text = 'Cargando...' }: { text?: string }) {
  return (
    <div role="status" className="flex items-center gap-3 text-slate-300">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-slate-500 border-t-amber-400" />
      <span>{text}</span>
    </div>
  )
}

export function FullScreenLoader({ text }: { text?: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <Spinner text={text} />
    </div>
  )
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-red-200">
      <p className="mb-3">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="rounded bg-red-500 px-3 py-1.5 text-sm font-semibold text-white hover:bg-red-400"
        >
          Reintentar
        </button>
      )}
    </div>
  )
}

export function EmptyState({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-slate-700 bg-slate-800/40 p-6 text-center text-slate-400">
      {message}
    </div>
  )
}

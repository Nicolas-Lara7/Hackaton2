import { useCallback, useEffect, useState } from 'react'
import { apiFetch, ApiError, isAbortError, toApiError } from '../lib/api'

interface ApiState<T> {
  data: T | null
  error: ApiError | null
  loading: boolean
}

// Hook genérico para GET: maneja loading, error, reintento y cancela la request anterior.
export function useApi<T>(path: string) {
  const [state, setState] = useState<ApiState<T>>({ data: null, error: null, loading: true })
  const [reloadKey, setReloadKey] = useState(0)

  useEffect(() => {
    const controller = new AbortController()
    setState((prev) => ({ ...prev, loading: true, error: null }))

    apiFetch<T>(path, { signal: controller.signal })
      .then((data) => {
        if (!controller.signal.aborted) setState({ data, error: null, loading: false })
      })
      .catch((error: unknown) => {
        if (isAbortError(error) || controller.signal.aborted) return
        setState({ data: null, error: toApiError(error), loading: false })
      })

    // Si cambia el path o se desmonta, cancelamos: una respuesta vieja nunca pisa a la nueva.
    return () => controller.abort()
  }, [path, reloadKey])

  const retry = useCallback(() => setReloadKey((key) => key + 1), [])

  return { ...state, retry }
}

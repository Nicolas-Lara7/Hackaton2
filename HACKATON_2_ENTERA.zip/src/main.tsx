import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter } from 'react-router'
import { RouterProvider } from 'react-router/dom'
import './index.css'
import { AuthProvider } from './auth/AuthContext'
import { AppLayout, RootLayout } from './components/Layouts'
import { PublicOnly, RequireAuth } from './components/RouteGuards'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import WantedListPage from './pages/WantedListPage'
import WantedDetailPage from './pages/WantedDetailPage'
import NotFoundPage from './pages/NotFoundPage'
import NewsFeedPage from './pages/NewsFeedPage'
import NewsDetailPage from './pages/NewsDetailPage'
import SagasPage from './pages/SagasPage'
import SagaStoryPage from './pages/SagaStoryPage'

const router = createBrowserRouter([
  {
    element: <RootLayout />,
    children: [
      // Públicas (si ya hay sesión, redirigen a la app)
      {
        element: <PublicOnly />,
        children: [
          { path: '/login', element: <LoginPage /> },
          { path: '/register', element: <RegisterPage /> },
        ],
      },
      // Privadas (sin sesión → login)
      {
        element: <RequireAuth />,
        children: [
          {
            element: <AppLayout />,
            children: [
              { path: '/', element: <DashboardPage /> },
              { path: '/wanted', element: <WantedListPage /> },
              { path: '/wanted/:id', element: <WantedDetailPage /> },
              { path: '/news', element: <NewsFeedPage /> },
              { path: '/news/:id', element: <NewsDetailPage /> },
              { path: '/sagas', element: <SagasPage /> },
              { path: '/sagas/:id', element: <SagaStoryPage /> },
            ],
          },
        ],
      },
      // 404
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  </StrictMode>,
)

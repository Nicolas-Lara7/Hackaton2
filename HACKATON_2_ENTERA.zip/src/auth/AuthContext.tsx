import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { apiFetch, isAbortError, setUnauthorizedHandler, tokenStorage } from '../lib/api'
import type { LoginResponse, MeResponse, Team, User } from '../types'

// checking = estamos verificando el token guardado (no mostramos el login todavía)
type AuthStatus = 'checking' | 'authenticated' | 'anonymous'

interface AuthContextValue {
  status: AuthStatus
  user: User | null
  team: Team | null
  login: (email: string, password: string) => Promise<void>
  register: (teamName: string, email: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>(() => (tokenStorage.get() ? 'checking' : 'anonymous'))
  const [user, setUser] = useState<User | null>(null)
  const [team, setTeam] = useState<Team | null>(null)
  const [expiresAt, setExpiresAt] = useState<string | null>(null)

  const logout = useCallback(() => {
    tokenStorage.clear()
    setUser(null)
    setTeam(null)
    setExpiresAt(null)
    setStatus('anonymous')
  }, [])

  // 1) Si cualquier request responde 401, la sesión ya no es válida → al login.
  useEffect(() => {
    setUnauthorizedHandler(logout)
    return () => setUnauthorizedHandler(null)
  }, [logout])

  // 2) Restaurar sesión al recargar: si hay token, lo validamos con /auth/me.
  useEffect(() => {
    if (!tokenStorage.get()) return
    const controller = new AbortController()
    apiFetch<MeResponse>('/auth/me', { signal: controller.signal })
      .then((me) => {
        setUser(me.user)
        setTeam(me.team)
        setExpiresAt(me.expiresAt)
        setStatus('authenticated')
      })
      .catch((error: unknown) => {
        if (isAbortError(error)) return
        logout() // token inválido o vencido → login
      })
    return () => controller.abort()
  }, [logout])

  // 3) Cuando el token vence, cerramos la sesión automáticamente.
  useEffect(() => {
    if (!expiresAt) return
    const ms = new Date(expiresAt).getTime() - Date.now()
    if (ms <= 0) {
      logout()
      return
    }
    const timer = setTimeout(logout, Math.min(ms, 2_147_483_647))
    return () => clearTimeout(timer)
  }, [expiresAt, logout])

  const startSession = useCallback((data: LoginResponse) => {
    tokenStorage.set(data.token)
    setUser(data.user)
    setTeam(data.team)
    setExpiresAt(data.expiresAt)
    setStatus('authenticated')
  }, [])

  const login = useCallback(
    async (email: string, password: string) => {
      const data = await apiFetch<LoginResponse>('/auth/login', {
        method: 'POST',
        body: { email, password },
        auth: false,
      })
      startSession(data)
    },
    [startSession],
  )

  const register = useCallback(
    async (teamName: string, email: string, password: string) => {
      const data = await apiFetch<LoginResponse>('/auth/register', {
        method: 'POST',
        body: { teamName, email, password },
        auth: false,
      })
      startSession(data)
    },
    [startSession],
  )

  const value = useMemo(
    () => ({ status, user, team, login, register, logout }),
    [status, user, team, login, register, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth debe usarse dentro de <AuthProvider>')
  return context
}

// Nombre válido para view-transition-name (solo letras, números, - y _).
export function transitionName(sagaId: string): string {
  return `saga-${sagaId.replace(/[^a-zA-Z0-9_-]/g, '')}`
}

// ¿El usuario pidió reducir animaciones en su sistema?
export function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

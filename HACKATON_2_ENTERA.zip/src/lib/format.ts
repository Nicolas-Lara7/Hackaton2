import type { FruitFilter, NewsPriority, NewsStatus, NewsType, WantedStatus } from '../types'

export function formatBerries(amount: number): string {
  return `฿ ${new Intl.NumberFormat('es-PE').format(amount)}`
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('es-PE', { dateStyle: 'medium', timeStyle: 'short' })
}

export const STATUS_LABELS: Record<WantedStatus, string> = {
  AT_LARGE: 'Prófugo',
  CAPTURED: 'Capturado',
  MISSING: 'Desaparecido',
}

export const FRUIT_LABELS: Record<FruitFilter, string> = {
  PARAMECIA: 'Paramecia',
  ZOAN: 'Zoan',
  LOGIA: 'Logia',
  NONE: 'Sin fruta',
}

export const STATUS_COLORS: Record<WantedStatus, string> = {
  AT_LARGE: 'bg-red-500/20 text-red-300',
  CAPTURED: 'bg-emerald-500/20 text-emerald-300',
  MISSING: 'bg-slate-500/20 text-slate-300',
}

export const NEWS_TYPE_LABELS: Record<NewsType, string> = {
  BOUNTY_UPDATE: 'Recompensa',
  BATTLE: 'Batalla',
  MARINE_OPERATION: 'Operación Marine',
  WORLD_GOVERNMENT: 'Gobierno Mundial',
  DISCOVERY: 'Descubrimiento',
}

export const NEWS_PRIORITY_LABELS: Record<NewsPriority, string> = {
  LOW: 'Baja',
  MEDIUM: 'Media',
  HIGH: 'Alta',
  CRITICAL: 'Crítica',
}

export const NEWS_STATUS_LABELS: Record<NewsStatus, string> = {
  RUMOR: 'Rumor',
  CONFIRMED: 'Confirmada',
  DEBUNKED: 'Desmentida',
}

export const NEWS_STATUS_COLORS: Record<NewsStatus, string> = {
  RUMOR: 'bg-amber-500/20 text-amber-300',
  CONFIRMED: 'bg-emerald-500/20 text-emerald-300',
  DEBUNKED: 'bg-slate-500/20 text-slate-300',
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('es-PE').format(value)
}

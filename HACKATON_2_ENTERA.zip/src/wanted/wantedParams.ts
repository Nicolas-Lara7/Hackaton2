// Todo el estado del listado vive en la URL. Aquí lo leemos (validando) y lo escribimos.
import type { FruitFilter, WantedStatus } from '../types'

export const SIZES = [10, 20, 50] as const
export const SORTS = ['bounty,desc', 'name,asc', 'updatedAt,desc'] as const
export const STATUSES: readonly WantedStatus[] = ['AT_LARGE', 'CAPTURED', 'MISSING']
export const FRUITS: readonly FruitFilter[] = ['PARAMECIA', 'ZOAN', 'LOGIA', 'NONE']

export type PageSize = (typeof SIZES)[number]
export type SortOption = (typeof SORTS)[number]

export interface WantedFilters {
  page: number
  size: PageSize
  sort: SortOption
  status: WantedStatus | ''
  fruit: FruitFilter | ''
  crewId: string
  q: string
}

export const DEFAULT_FILTERS: WantedFilters = {
  page: 0,
  size: 20,
  sort: 'bounty,desc',
  status: '',
  fruit: '',
  crewId: '',
  q: '',
}

// Devuelve el valor solo si está en la lista permitida; si no, el valor por defecto.
function oneOf<T extends string | number>(value: string | null, allowed: readonly T[], fallback: T): T {
  const found = allowed.find((option) => String(option) === value)
  return found ?? fallback
}

// Igual, pero para filtros opcionales: si no es válido, '' (= sin filtro).
function optionalOneOf<T extends string>(value: string | null, allowed: readonly T[]): T | '' {
  return allowed.find((option) => option === value) ?? ''
}

// URL → filtros. Cualquier valor inválido se reemplaza por el valor por defecto (la vista nunca se rompe).
export function parseFilters(params: URLSearchParams): WantedFilters {
  const pageNumber = Number(params.get('page') ?? '0')
  return {
    page: Number.isInteger(pageNumber) && pageNumber >= 0 && pageNumber < 100_000 ? pageNumber : 0,
    size: oneOf(params.get('size'), SIZES, DEFAULT_FILTERS.size),
    sort: oneOf(params.get('sort'), SORTS, DEFAULT_FILTERS.sort),
    status: optionalOneOf(params.get('status'), STATUSES),
    fruit: optionalOneOf(params.get('fruit'), FRUITS),
    crewId: (params.get('crewId') ?? '').trim().slice(0, 200),
    q: (params.get('q') ?? '').trim().slice(0, 100),
  }
}

// Filtros → URL. Solo escribimos lo que no es el valor por defecto (URL limpia y única).
export function toSearchParams(filters: WantedFilters): URLSearchParams {
  const params = new URLSearchParams()
  if (filters.q) params.set('q', filters.q)
  if (filters.status) params.set('status', filters.status)
  if (filters.crewId) params.set('crewId', filters.crewId)
  if (filters.fruit) params.set('fruit', filters.fruit)
  if (filters.sort !== DEFAULT_FILTERS.sort) params.set('sort', filters.sort)
  if (filters.size !== DEFAULT_FILTERS.size) params.set('size', String(filters.size))
  if (filters.page !== 0) params.set('page', String(filters.page))
  return params
}

// Filtros → query string para la API.
export function toApiQuery(filters: WantedFilters): string {
  const params = new URLSearchParams()
  params.set('page', String(filters.page))
  params.set('size', String(filters.size))
  params.set('sort', filters.sort)
  if (filters.status) params.set('status', filters.status)
  if (filters.crewId) params.set('crewId', filters.crewId)
  if (filters.fruit) params.set('fruit', filters.fruit)
  if (filters.q) params.set('q', filters.q)
  return params.toString()
}

// Filtros del feed en la URL + memoria del feed ya cargado (para volver del detalle sin pedir de nuevo).
import type { NewsItem, NewsPriority, NewsStatus, NewsType } from '../types'

export const NEWS_TYPES: readonly NewsType[] = ['BOUNTY_UPDATE', 'BATTLE', 'MARINE_OPERATION', 'WORLD_GOVERNMENT', 'DISCOVERY']
export const NEWS_PRIORITIES: readonly NewsPriority[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
export const NEWS_STATUSES: readonly NewsStatus[] = ['RUMOR', 'CONFIRMED', 'DEBUNKED']

export interface NewsFilters {
  type: NewsType | ''
  priority: NewsPriority | ''
  status: NewsStatus | ''
}

function optionalOneOf<T extends string>(value: string | null, allowed: readonly T[]): T | '' {
  return allowed.find((option) => option === value) ?? ''
}

// URL → filtros (valores inválidos = sin filtro)
export function parseNewsFilters(params: URLSearchParams): NewsFilters {
  return {
    type: optionalOneOf(params.get('type'), NEWS_TYPES),
    priority: optionalOneOf(params.get('priority'), NEWS_PRIORITIES),
    status: optionalOneOf(params.get('status'), NEWS_STATUSES),
  }
}

// Filtros → URL / clave del feed
export function newsFiltersToParams(filters: NewsFilters): URLSearchParams {
  const params = new URLSearchParams()
  if (filters.type) params.set('type', filters.type)
  if (filters.priority) params.set('priority', filters.priority)
  if (filters.status) params.set('status', filters.status)
  return params
}

// ---------- Memoria del feed ----------
export interface FeedState {
  items: NewsItem[]
  nextCursor: string | null
  hasMore: boolean
}

export const EMPTY_FEED: FeedState = { items: [], nextCursor: null, hasMore: true }

// Una entrada por combinación de filtros. Vive fuera de React: sobrevive al ir al detalle.
const feeds = new Map<string, FeedState>()

export function getFeed(key: string): FeedState | undefined {
  return feeds.get(key)
}

export function saveFeed(key: string, feed: FeedState): void {
  feeds.set(key, feed)
}

export function clearFeed(key: string): void {
  feeds.delete(key)
}

// Regla de Nami: agregamos solo las noticias cuyo id no teníamos.
export function appendUnique(current: NewsItem[], incoming: NewsItem[]): NewsItem[] {
  const seen = new Set(current.map((item) => item.id))
  const fresh = incoming.filter((item) => {
    if (seen.has(item.id)) return false
    seen.add(item.id)
    return true
  })
  return [...current, ...fresh]
}

// Tras verificar una noticia, actualizamos su estado en todos los feeds guardados.
export function updateNewsInFeeds(updated: NewsItem): void {
  for (const [key, feed] of feeds) {
    feeds.set(key, {
      ...feed,
      items: feed.items.map((item) =>
        item.id === updated.id
          ? { ...item, status: updated.status, verifiedAt: updated.verifiedAt, updatedAt: updated.updatedAt }
          : item,
      ),
    })
  }
}

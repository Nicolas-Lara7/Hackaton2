/// <reference types="vite/client" />

// Le decimos a TypeScript qué variables de entorno existen.
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string
}

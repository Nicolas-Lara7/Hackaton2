import { useCallback, useEffect, useRef, useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router'
import { useApi } from '../hooks/useApi'
import { errorMessage } from '../lib/api'
import { ErrorBox, Spinner } from '../components/StatusViews'
import { formatNumber } from '../lib/format'
import { prefersReducedMotion, transitionName } from '../saga/sagaUtils'
import type { SagaStory } from '../types'

// ---------- Mapa del Grand Line (SVG con las coordenadas que manda el backend) ----------
function SagaMap({ story, active, onSelect }: { story: SagaStory; active: number; onSelect: (index: number) => void }) {
  const { width, height } = story.map
  const theme = story.stages[active].palette
  const allPoints = story.stages.map((s) => `${s.island.x},${s.island.y}`)
  const traveled = allPoints.slice(0, active + 1).join(' ') // ruta recorrida hasta la etapa activa
  const ship = story.stages[active].island

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-label={`Mapa: el barco está en ${ship.name}`}
      className="h-auto w-full rounded-lg"
    >
      <rect width={width} height={height} fill={theme.surface} />
      {/* Ruta completa (punteada) */}
      <polyline points={allPoints.join(' ')} fill="none" stroke={theme.text} strokeOpacity={0.3} strokeWidth={3} strokeDasharray="8 10" />
      {/* Ruta recorrida */}
      <polyline points={traveled} fill="none" stroke={theme.accent} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
      {/* Islas */}
      {story.stages.map((stage, index) => (
        <g key={stage.id} onClick={() => onSelect(index)} className="cursor-pointer">
          <circle
            cx={stage.island.x}
            cy={stage.island.y}
            r={index === active ? 14 : 9}
            fill={index <= active ? theme.accent : theme.surface}
            stroke={theme.text}
            strokeWidth={2}
          />
          <text
            x={stage.island.x}
            y={stage.island.y + (stage.island.y < height / 2 ? 36 : -22)}
            textAnchor="middle"
            fontSize={22}
            fill={theme.text}
            fontWeight={index === active ? 700 : 400}
          >
            {stage.island.name}
          </text>
        </g>
      ))}
      {/* Barco: se mueve a la isla de la etapa activa */}
      <g className="saga-ship" style={{ transform: `translate(${ship.x}px, ${ship.y}px)` }}>
        <text textAnchor="middle" dominantBaseline="central" fontSize={34}>
          ⛵
        </text>
      </g>
    </svg>
  )
}

export default function SagaStoryPage() {
  const { id = '' } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()
  const { data, error, loading, retry } = useApi<SagaStory>(`/sagas/${encodeURIComponent(id)}/story`)

  const [active, setActive] = useState(0)
  const [ready, setReady] = useState(false)
  const sectionRefs = useRef<(HTMLElement | null)[]>([])
  const progressRef = useRef<HTMLDivElement | null>(null)

  // A) Al llegar los datos: ir directo a la etapa que indica la URL (?stage=slug).
  useEffect(() => {
    if (!data || data.stages.length === 0) return
    const slug = searchParams.get('stage')
    const index = Math.max(0, data.stages.findIndex((s) => s.slug === slug)) // slug inválido → etapa 1
    setActive(index)
    if (slug) sectionRefs.current[index]?.scrollIntoView({ block: 'start' })
    setReady(true)
    // solo cuando llegan los datos (no cada vez que cambia la URL)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data])

  // B) Etapa activa por scroll: IntersectionObserver mira qué sección cruza el centro de la pantalla.
  useEffect(() => {
    if (!data) return
    const isMobile = window.matchMedia('(max-width: 1023px)').matches
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActive(Number((entry.target as HTMLElement).dataset.index))
        }
      },
      // En mobile el mapa ocupa la parte de arriba, así que la "línea" de lectura va más abajo.
      { rootMargin: isMobile ? '-65% 0px -30% 0px' : '-45% 0px -50% 0px' },
    )
    sectionRefs.current.forEach((el) => {
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [data])

  // C) La URL siempre indica la etapa activa.
  useEffect(() => {
    if (!data || !ready) return
    const slug = data.stages[active]?.slug
    if (slug && searchParams.get('stage') !== slug) setSearchParams({ stage: slug }, { replace: true })
  }, [active, ready, data, searchParams, setSearchParams])

  // D) Fallback de la barra de progreso cuando el navegador no soporta scroll-driven animations.
  useEffect(() => {
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight
      const ratio = max > 0 ? window.scrollY / max : 0
      progressRef.current?.style.setProperty('--progress', String(Math.min(Math.max(ratio, 0), 1)))
    }
    update()
    window.addEventListener('scroll', update, { passive: true })
    return () => window.removeEventListener('scroll', update)
  }, [data])

  // E) Navegación por teclado entre etapas.
  const goTo = useCallback(
    (index: number) => {
      if (!data) return
      const target = Math.min(Math.max(index, 0), data.stages.length - 1)
      const section = sectionRefs.current[target]
      if (!section) return
      section.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'start' })
      section.focus({ preventScroll: true }) // el foco va al contenido: nada se pierde
      setActive(target)
    },
    [data],
  )

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return
      if (event.key === 'ArrowRight' || event.key === 'n') {
        event.preventDefault()
        goTo(active + 1)
      } else if (event.key === 'ArrowLeft' || event.key === 'p') {
        event.preventDefault()
        goTo(active - 1)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [active, goTo])

  if (loading) return <Spinner text="Descifrando el Poneglyph..." />
  if (error) return <ErrorBox message={error.status === 404 ? 'Esta saga no existe.' : errorMessage(error)} onRetry={error.status === 404 ? undefined : retry} />
  if (!data || data.stages.length === 0) return <ErrorBox message="La saga no tiene etapas." />

  const stage = data.stages[active]
  const theme = stage.palette // colores de la etapa activa
  const total = data.stages.length

  return (
    <div
      className="saga-theme -mx-4 rounded-xl px-4 pb-24 pt-6"
      style={{ backgroundColor: theme.background, color: theme.text }}
    >
      {/* Barra de progreso de lectura: scroll-driven animation (o fallback con --progress) */}
      <div
        ref={progressRef}
        className="saga-scroll-progress fixed left-0 top-0 z-50 h-1.5 w-full"
        style={{ backgroundColor: theme.accent }}
        aria-hidden="true"
      />

      <Link to="/sagas" viewTransition className="text-sm underline" style={{ color: theme.accent }}>
        ← Volver a las sagas
      </Link>

      <header className="mb-8 mt-4 space-y-2">
        <p className="text-xs uppercase tracking-widest" style={{ color: theme.accent }}>
          Saga {data.saga.order}
        </p>
        <h1
          className="text-3xl font-bold"
          ref={(el) => {
            if (el) el.style.setProperty('view-transition-name', transitionName(data.saga.id))
          }}
        >
          {data.saga.title}
        </h1>
        <p className="opacity-80">{data.saga.subtitle}</p>
        <p className="max-w-2xl leading-relaxed">{data.saga.intro}</p>
        <p className="text-sm opacity-70">Usa ← → (o los botones) para moverte entre etapas.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Panel persistente: mapa + progreso + métricas */}
        <aside
          className="saga-theme sticky top-0 z-10 self-start space-y-3 py-2 lg:top-4"
          style={{ backgroundColor: theme.background }}
        >
          <SagaMap story={data} active={active} onSelect={goTo} />

          {/* Progreso del recorrido */}
          <div>
            <div className="mb-1 flex justify-between text-sm">
              <span>
                Etapa {active + 1} de {total} · {stage.island.name}
              </span>
              <span>{Math.round(((active + 1) / total) * 100)}%</span>
            </div>
            <div className="h-2 w-full rounded-full" style={{ backgroundColor: theme.surface }}>
              <div
                className="saga-progress-fill h-2 rounded-full"
                style={{ width: `${((active + 1) / total) * 100}%`, backgroundColor: theme.accent }}
              />
            </div>
          </div>

          {/* Métricas de la etapa activa */}
          <dl className="grid grid-cols-4 gap-2" aria-live="polite">
            {stage.metrics.map((metric) => (
              <div key={metric.key} className="rounded-lg p-2" style={{ backgroundColor: theme.surface }}>
                <dt className="text-[11px] opacity-80">{metric.label}</dt>
                <dd className="text-sm font-bold" style={{ color: theme.primary }}>
                  {formatNumber(metric.value)} {metric.unit}
                </dd>
              </div>
            ))}
          </dl>

          {/* Navegación (teclado y mouse) */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => goTo(active - 1)}
              disabled={active === 0}
              className="rounded px-3 py-1.5 text-sm font-semibold disabled:opacity-40"
              style={{ backgroundColor: theme.surface }}
            >
              ← Anterior
            </button>
            <div className="hidden flex-1 justify-center gap-1 sm:flex">
              {data.stages.map((s, index) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => goTo(index)}
                  aria-label={`Ir a la etapa ${index + 1}: ${s.title}`}
                  aria-current={index === active ? 'step' : undefined}
                  className="h-7 w-7 rounded-full text-xs font-bold"
                  style={{
                    backgroundColor: index === active ? theme.accent : theme.surface,
                    color: index === active ? theme.background : theme.text,
                  }}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => goTo(active + 1)}
              disabled={active === total - 1}
              className="ml-auto rounded px-3 py-1.5 text-sm font-semibold disabled:opacity-40"
              style={{ backgroundColor: theme.surface }}
            >
              Siguiente →
            </button>
          </div>
        </aside>

        {/* Narrativa por etapas */}
        <div className="space-y-8">
          {data.stages.map((s, index) => (
            <section
              key={s.id}
              id={s.slug}
              data-index={index}
              data-active={index === active}
              tabIndex={-1}
              aria-labelledby={`stage-title-${s.id}`}
              ref={(el) => {
                sectionRefs.current[index] = el
              }}
              className="saga-stage flex min-h-[70vh] scroll-mt-[50vh] flex-col justify-center rounded-xl p-6 outline-none focus-visible:ring-2 lg:scroll-mt-8"
              style={{ backgroundColor: s.palette.surface, color: s.palette.text }}
            >
              <p className="text-xs uppercase tracking-widest" style={{ color: s.palette.accent }}>
                Etapa {s.order} · {s.island.name}
              </p>
              <h2 id={`stage-title-${s.id}`} className="mb-4 mt-1 text-2xl font-bold">
                {s.title}
              </h2>
              <div className="space-y-3 leading-relaxed">
                {s.narrative.map((paragraph, i) => (
                  <p key={i}>{paragraph}</p>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  )
}

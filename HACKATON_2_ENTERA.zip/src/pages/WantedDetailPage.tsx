import { Link, useLocation, useNavigate, useParams } from 'react-router'
import { useApi } from '../hooks/useApi'
import { ErrorBox, Spinner } from '../components/StatusViews'
import { formatBerries, formatDate, FRUIT_LABELS, STATUS_COLORS, STATUS_LABELS } from '../lib/format'
import type { WantedDetail } from '../types'

export default function WantedDetailPage() {
  const { id = '' } = useParams()
  const location = useLocation()
  const navigate = useNavigate()
  const { data, error, loading, retry } = useApi<WantedDetail>(`/wanted/${encodeURIComponent(id)}`)

  // Si venimos del listado, "volver" = atrás del navegador → el listado queda igual que como se dejó.
  const cameFromList = (location.state as { fromList?: boolean } | null)?.fromList === true

  const backButton = cameFromList ? (
    <button type="button" onClick={() => navigate(-1)} className="text-amber-400 hover:underline">
      ← Volver al listado
    </button>
  ) : (
    <Link to="/wanted" className="text-amber-400 hover:underline">
      ← Ir al listado
    </Link>
  )

  return (
    <div className="space-y-4">
      {backButton}

      {loading && <Spinner text="Cargando cartel..." />}

      {!loading && error && (
        <ErrorBox
          message={error.status === 404 ? 'Este cartel no existe.' : error.message}
          onRetry={error.status === 404 ? undefined : retry}
        />
      )}

      {!loading && !error && data && (
        <article className="space-y-6 rounded-xl border border-amber-500/30 bg-slate-900 p-6">
          <header className="space-y-1">
            <p className="text-sm uppercase tracking-widest text-amber-400">Se busca</p>
            <h1 className="text-3xl font-bold">{data.name}</h1>
            <p className="text-slate-400">“{data.epithet}”</p>
            <p className="pt-2 font-mono text-2xl text-amber-300">{formatBerries(data.bounty)}</p>
          </header>

          <dl className="grid gap-3 sm:grid-cols-2">
            <div>
              <dt className="text-sm text-slate-400">Estado</dt>
              <dd>
                <span className={`rounded-full px-2 py-0.5 text-sm ${STATUS_COLORS[data.status]}`}>
                  {STATUS_LABELS[data.status]}
                </span>
              </dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Tripulación · Rol</dt>
              <dd>
                {data.crew?.name ?? '—'} · {data.role}
              </dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Fruta del diablo</dt>
              <dd>{data.devilFruit ? `${data.devilFruit.name} (${FRUIT_LABELS[data.devilFruit.type]})` : 'Ninguna'}</dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Nivel de amenaza</dt>
              <dd>{'★'.repeat(data.threatLevel)}</dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Edad · Altura</dt>
              <dd>
                {data.age} años · {data.heightCm} cm
              </dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Última vez visto</dt>
              <dd>
                {data.lastSeen ? `${data.lastSeen.island} · ${formatDate(data.lastSeen.seenAt)}` : data.lastSeenIsland}
              </dd>
            </div>
          </dl>

          <p className="leading-relaxed text-slate-300">{data.bio}</p>

          <section>
            <h2 className="mb-2 font-semibold">Historial de recompensas</h2>
            <ul className="space-y-1">
              {data.bountyHistory.map((entry) => (
                <li key={entry.issuedAt} className="flex justify-between border-b border-slate-800 py-1 text-sm">
                  <span className="text-slate-400">{formatDate(entry.issuedAt)}</span>
                  <span className="font-mono">{formatBerries(entry.amount)}</span>
                </li>
              ))}
            </ul>
          </section>
        </article>
      )}
    </div>
  )
}

import { Link } from 'react-router'
import { useApi } from '../hooks/useApi'
import { errorMessage } from '../lib/api'
import { EmptyState, ErrorBox, Spinner } from '../components/StatusViews'
import { formatNumber } from '../lib/format'
import { transitionName } from '../saga/sagaUtils'
import type { SagaSummary } from '../types'

export default function SagasPage() {
  const { data, error, loading, retry } = useApi<SagaSummary[]>('/sagas')

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Poneglyphs: las sagas</h1>

      {loading && <Spinner text="Cargando sagas..." />}
      {!loading && error && <ErrorBox message={errorMessage(error)} onRetry={retry} />}
      {!loading && !error && data && data.length === 0 && <EmptyState message="No hay sagas disponibles." />}

      {!loading && !error && data && data.length > 0 && (
        <ul className="grid gap-4 md:grid-cols-2">
          {data.map((saga) => (
            <li key={saga.id}>
              {/* viewTransition: React Router usa la View Transition API si el navegador la soporta;
                  si no, navega normal. */}
              <Link
                to={`/sagas/${saga.id}`}
                viewTransition
                className="block h-full rounded-xl border p-5 transition hover:-translate-y-0.5"
                style={{ backgroundColor: saga.palette.background, color: saga.palette.text, borderColor: saga.palette.primary }}
              >
                <p className="text-xs uppercase tracking-widest" style={{ color: saga.palette.accent }}>
                  Saga {saga.order}
                </p>
                <h2
                  className="mt-1 text-xl font-bold"
                  ref={(el) => {
                    if (el) el.style.setProperty('view-transition-name', transitionName(saga.id))
                  }}
                >
                  {saga.title}
                </h2>
                <p className="text-sm opacity-80">{saga.subtitle}</p>
                <p className="mt-3 text-sm">{saga.synopsis}</p>
                <p className="mt-4 text-xs opacity-80">
                  {saga.firstIsland} → {saga.lastIsland} · {saga.stageCount} etapas · {formatNumber(saga.totalDistanceNm)} mn
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router'
import { apiFetch, ApiError, isAbortError, toApiError } from '../lib/api'
import { useApi } from '../hooks/useApi'
import { EmptyState, ErrorBox, Spinner } from '../components/StatusViews'
import { formatBerries, FRUIT_LABELS, STATUS_COLORS, STATUS_LABELS } from '../lib/format'
import { FRUITS, parseFilters, SIZES, SORTS, STATUSES, toApiQuery, toSearchParams } from '../wanted/wantedParams'
import type { WantedFilters } from '../wanted/wantedParams'
import type { Crew, FruitFilter, WantedPage, WantedStatus } from '../types'

// Caché en memoria: al volver del detalle, la página se muestra al instante (y el scroll se restaura).
const pageCache = new Map<string, WantedPage>()

interface PageState {
  data: WantedPage | null
  dataKey: string | null // a qué consulta pertenece `data`
  error: ApiError | null
  loading: boolean
}

function useWantedPage(apiQuery: string) {
  const [state, setState] = useState<PageState>(() => {
    const cached = pageCache.get(apiQuery)
    return { data: cached ?? null, dataKey: cached ? apiQuery : null, error: null, loading: !cached }
  })
  const [reloadKey, setReloadKey] = useState(0)

  useEffect(() => {
    const cached = pageCache.get(apiQuery)
    if (cached) {
      setState({ data: cached, dataKey: apiQuery, error: null, loading: false })
      return
    }

    // AbortController: si el usuario cambia algo, cancelamos la request anterior.
    // Así una respuesta vieja que llega tarde NUNCA reemplaza a la nueva.
    const controller = new AbortController()
    setState((prev) => ({ ...prev, error: null, loading: true }))

    apiFetch<WantedPage>(`/wanted?${apiQuery}`, { signal: controller.signal })
      .then((data) => {
        if (controller.signal.aborted) return
        pageCache.set(apiQuery, data)
        setState({ data, dataKey: apiQuery, error: null, loading: false })
      })
      .catch((error: unknown) => {
        if (isAbortError(error) || controller.signal.aborted) return
        setState((prev) => ({ ...prev, error: toApiError(error), loading: false }))
      })

    return () => controller.abort()
  }, [apiQuery, reloadKey])

  const retry = useCallback(() => setReloadKey((key) => key + 1), [])
  return { ...state, retry }
}

export default function WantedListPage() {
  const [searchParams, setSearchParams] = useSearchParams()

  // 1) La URL es la única fuente de verdad.
  const filters = useMemo(() => parseFilters(searchParams), [searchParams])
  const apiQuery = toApiQuery(filters)
  const canonical = toSearchParams(filters).toString()

  // 2) Cambiar filtros: cualquier cambio que no sea de página vuelve a la página 0.
  const updateFilters = useCallback(
    (changes: Partial<WantedFilters>, options?: { replace?: boolean }) => {
      setSearchParams((prev) => {
        const next: WantedFilters = { ...parseFilters(prev), ...changes }
        if (changes.page === undefined) next.page = 0
        return toSearchParams(next)
      }, options)
    },
    [setSearchParams],
  )

  // 3) URL con valores inválidos → la corregimos sin romper la vista.
  useEffect(() => {
    if (canonical !== searchParams.toString()) setSearchParams(canonical, { replace: true })
  }, [canonical, searchParams, setSearchParams])

  // 4) Búsqueda con debounce: solo pedimos al servidor cuando el usuario deja de escribir 400 ms.
  const [searchInput, setSearchInput] = useState(filters.q)

  useEffect(() => {
    // si la URL cambia (atrás/adelante), sincronizamos el input
    setSearchInput((prev) => (prev.trim() === filters.q ? prev : filters.q))
  }, [filters.q])

  useEffect(() => {
    const trimmed = searchInput.trim()
    if (trimmed === filters.q) return
    const timer = setTimeout(() => updateFilters({ q: trimmed }, { replace: true }), 400)
    return () => clearTimeout(timer)
  }, [searchInput, filters.q, updateFilters])

  const { data, dataKey, error, loading, retry } = useWantedPage(apiQuery)
  const crews = useApi<Crew[]>('/crews')

  // 5) Nunca quedarse en una página que no existe.
  useEffect(() => {
    if (!data || dataKey !== apiQuery) return
    const lastPage = Math.max(data.totalPages - 1, 0)
    if (filters.page > lastPage) updateFilters({ page: lastPage }, { replace: true })
  }, [data, dataKey, apiQuery, filters.page, updateFilters])

  const isCurrent = dataKey === apiQuery
  const selectClass = 'rounded border border-slate-700 bg-slate-800 px-2 py-2 text-sm'

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Carteles de “Se Busca”</h1>

      {/* Controles */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        <input
          type="search"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          placeholder="Buscar por nombre o epíteto..."
          maxLength={100}
          aria-label="Buscar"
          className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-sm lg:col-span-2"
        />

        <select
          aria-label="Estado"
          value={filters.status}
          onChange={(e) => updateFilters({ status: e.target.value as WantedStatus | '' })}
          className={selectClass}
        >
          <option value="">Todos los estados</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>

        <select
          aria-label="Tripulación"
          value={filters.crewId}
          onChange={(e) => updateFilters({ crewId: e.target.value })}
          className={selectClass}
        >
          <option value="">Todas las tripulaciones</option>
          {crews.data?.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
          {/* si la URL trae una tripulación que aún no cargó, igual la mostramos */}
          {filters.crewId && !crews.data?.some((c) => c.id === filters.crewId) && (
            <option value={filters.crewId}>{crews.loading ? 'Cargando...' : filters.crewId}</option>
          )}
        </select>

        <select
          aria-label="Fruta del diablo"
          value={filters.fruit}
          onChange={(e) => updateFilters({ fruit: e.target.value as FruitFilter | '' })}
          className={selectClass}
        >
          <option value="">Todas las frutas</option>
          {FRUITS.map((f) => (
            <option key={f} value={f}>
              {FRUIT_LABELS[f]}
            </option>
          ))}
        </select>

        <div className="flex gap-2">
          <select
            aria-label="Ordenar"
            value={filters.sort}
            onChange={(e) => updateFilters({ sort: e.target.value as WantedFilters['sort'] })}
            className={`${selectClass} flex-1`}
          >
            {SORTS.map((s) => (
              <option key={s} value={s}>
                {s === 'bounty,desc' ? 'Mayor recompensa' : s === 'name,asc' ? 'Nombre A-Z' : 'Más recientes'}
              </option>
            ))}
          </select>
          <select
            aria-label="Tamaño de página"
            value={filters.size}
            onChange={(e) => updateFilters({ size: Number(e.target.value) as WantedFilters['size'] })}
            className={selectClass}
          >
            {SIZES.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Resultados: altura mínima fija para que el layout no salte entre estados */}
      <div className="relative min-h-[28rem]" aria-busy={loading}>
        {error ? (
          <ErrorBox message={error.message} onRetry={retry} />
        ) : !data ? (
          <div className="space-y-2">
            {Array.from({ length: 10 }, (_, i) => (
              <div key={i} className="h-12 animate-pulse rounded bg-slate-800/60" />
            ))}
          </div>
        ) : isCurrent && data.content.length === 0 ? (
          <EmptyState message="No hay carteles que coincidan con estos filtros." />
        ) : (
          <div className={`overflow-x-auto transition-opacity ${loading ? 'opacity-40' : ''}`}>
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-700 text-slate-400">
                <tr>
                  <th className="px-3 py-2">Nombre</th>
                  <th className="px-3 py-2">Tripulación</th>
                  <th className="px-3 py-2 text-right">Recompensa</th>
                  <th className="px-3 py-2">Estado</th>
                  <th className="px-3 py-2">Fruta</th>
                  <th className="px-3 py-2">Amenaza</th>
                </tr>
              </thead>
              <tbody>
                {data.content.map((w) => (
                  <tr key={w.id} className="border-b border-slate-800 hover:bg-slate-800/50">
                    <td className="px-3 py-2">
                      <Link to={`/wanted/${w.id}`} state={{ fromList: true }} className="font-medium hover:text-amber-400">
                        {w.name}
                      </Link>
                      <div className="text-xs text-slate-500">“{w.epithet}”</div>
                    </td>
                    <td className="px-3 py-2">{w.crew?.name ?? '—'}</td>
                    <td className="px-3 py-2 text-right font-mono">{formatBerries(w.bounty)}</td>
                    <td className="px-3 py-2">
                      <span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_COLORS[w.status]}`}>
                        {STATUS_LABELS[w.status]}
                      </span>
                    </td>
                    <td className="px-3 py-2">{w.devilFruit ? `${w.devilFruit.name} (${FRUIT_LABELS[w.devilFruit.type]})` : '—'}</td>
                    <td className="px-3 py-2">{'★'.repeat(w.threatLevel)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {loading && data && !error && (
          <div className="absolute inset-x-0 top-10 flex justify-center">
            <div className="rounded bg-slate-900 px-4 py-2 shadow">
              <Spinner />
            </div>
          </div>
        )}
      </div>

      {/* Paginación real del servidor */}
      <div className="flex items-center justify-between gap-3 text-sm">
        <span className="text-slate-400">
          {data && isCurrent
            ? `Página ${data.totalPages === 0 ? 0 : filters.page + 1} de ${data.totalPages} · ${data.totalElements} carteles`
            : ' '}
        </span>
        <div className="flex gap-2">
          <button
            type="button"
            disabled={filters.page === 0}
            onClick={() => updateFilters({ page: filters.page - 1 })}
            className="rounded border border-slate-600 px-3 py-1.5 disabled:opacity-40"
          >
            ← Anterior
          </button>
          <button
            type="button"
            disabled={!data || !isCurrent || filters.page >= data.totalPages - 1}
            onClick={() => updateFilters({ page: filters.page + 1 })}
            className="rounded border border-slate-600 px-3 py-1.5 disabled:opacity-40"
          >
            Siguiente →
          </button>
        </div>
      </div>
    </div>
  )
}

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router'
import { apiFetch, ApiError, errorMessage, isAbortError, toApiError } from '../lib/api'
import { EmptyState, ErrorBox, Spinner } from '../components/StatusViews'
import {
  formatDate,
  NEWS_PRIORITY_LABELS,
  NEWS_STATUS_COLORS,
  NEWS_STATUS_LABELS,
  NEWS_TYPE_LABELS,
} from '../lib/format'
import {
  appendUnique,
  clearFeed,
  EMPTY_FEED,
  getFeed,
  NEWS_PRIORITIES,
  NEWS_STATUSES,
  NEWS_TYPES,
  newsFiltersToParams,
  parseNewsFilters,
  saveFeed,
} from '../news/newsStore'
import type { FeedState, NewsFilters } from '../news/newsStore'
import type { NewsFeed } from '../types'

const PAGE_LIMIT = 20

export default function NewsFeedPage() {
  const [searchParams, setSearchParams] = useSearchParams()

  // 1) Filtros en la URL. La clave identifica "este feed" (esta combinación de filtros).
  const filters = useMemo(() => parseNewsFilters(searchParams), [searchParams])
  const feedKey = newsFiltersToParams(filters).toString()

  // Si la URL traía valores inválidos, la limpiamos.
  useEffect(() => {
    if (feedKey !== searchParams.toString()) setSearchParams(feedKey, { replace: true })
  }, [feedKey, searchParams, setSearchParams])

  const [feed, setFeed] = useState<FeedState>(() => getFeed(feedKey) ?? EMPTY_FEED)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<ApiError | null>(null)

  // Refs: valores que no deben provocar re-render.
  const inFlight = useRef<AbortController | null>(null) // la carga en vuelo (solo una)
  const currentKey = useRef(feedKey) // filtros vigentes
  const sentinelRef = useRef<HTMLDivElement | null>(null)

  // 2) Cargar una página del feed.
  const loadPage = useCallback((key: string, cursor: string | null) => {
    if (inFlight.current) return // una sola carga adicional en vuelo

    const controller = new AbortController()
    inFlight.current = controller
    setLoading(true)
    setError(null)

    const params = new URLSearchParams(key)
    params.set('limit', String(PAGE_LIMIT))
    if (cursor) params.set('cursor', cursor)

    apiFetch<NewsFeed>(`/news/feed?${params.toString()}`, { signal: controller.signal })
      .then((page) => {
        // Si cambiaron los filtros mientras tanto, esta respuesta se descarta (no se mezclan resultados).
        if (controller.signal.aborted || currentKey.current !== key) return
        const previous = getFeed(key) ?? EMPTY_FEED
        const next: FeedState = {
          items: appendUnique(previous.items, page.items), // ninguna noticia dos veces
          nextCursor: page.nextCursor,
          hasMore: page.hasMore && page.nextCursor !== null,
        }
        saveFeed(key, next)
        setFeed(next)
      })
      .catch((err: unknown) => {
        if (isAbortError(err) || controller.signal.aborted || currentKey.current !== key) return
        const apiError = toApiError(err)
        // Cursor inválido o de otros filtros → empezamos el feed de nuevo.
        if (apiError.code === 'INVALID_CURSOR' || apiError.code === 'CURSOR_FILTER_MISMATCH') {
          clearFeed(key)
          setFeed(EMPTY_FEED)
        }
        // Error normal: NO borramos las noticias ya cargadas.
        setError(apiError)
      })
      .finally(() => {
        if (inFlight.current === controller) {
          inFlight.current = null
          setLoading(false)
        }
      })
  }, [])

  // 3) Al cambiar filtros: cancelamos lo que estaba en vuelo y empezamos (o usamos lo guardado).
  useEffect(() => {
    currentKey.current = feedKey
    inFlight.current?.abort()
    inFlight.current = null
    setLoading(false)
    setError(null)

    const saved = getFeed(feedKey)
    setFeed(saved ?? EMPTY_FEED)
    if (!saved) loadPage(feedKey, null)

    return () => {
      inFlight.current?.abort()
      inFlight.current = null
    }
  }, [feedKey, loadPage])

  // 4) Infinite scroll: cuando el "sentinel" del final entra en pantalla, cargamos la siguiente página.
  useEffect(() => {
    const sentinel = sentinelRef.current
    if (!sentinel || error) return // si hubo error, esperamos al botón Reintentar

    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries[0]?.isIntersecting) return
        const saved = getFeed(currentKey.current)
        if (!saved || !saved.hasMore || !saved.nextCursor) return
        loadPage(currentKey.current, saved.nextCursor)
      },
      { rootMargin: '400px' },
    )
    observer.observe(sentinel)
    return () => observer.disconnect()
    // se vuelve a crear cuando llegan noticias nuevas: así, si el sentinel sigue visible, carga otra vez
  }, [feed.items.length, error, loadPage])

  const retry = () => {
    const saved = getFeed(currentKey.current)
    loadPage(currentKey.current, saved?.nextCursor ?? null)
  }

  const updateFilter = (changes: Partial<NewsFilters>) => {
    setSearchParams(newsFiltersToParams({ ...filters, ...changes }))
  }

  const selectClass = 'rounded border border-slate-700 bg-slate-800 px-2 py-2 text-sm'
  const isFirstLoad = feed.items.length === 0

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Noticias del mundo</h1>

      <div className="grid gap-3 sm:grid-cols-3">
        <select
          aria-label="Tipo"
          value={filters.type}
          onChange={(e) => updateFilter({ type: e.target.value as NewsFilters['type'] })}
          className={selectClass}
        >
          <option value="">Todos los tipos</option>
          {NEWS_TYPES.map((t) => (
            <option key={t} value={t}>
              {NEWS_TYPE_LABELS[t]}
            </option>
          ))}
        </select>
        <select
          aria-label="Prioridad"
          value={filters.priority}
          onChange={(e) => updateFilter({ priority: e.target.value as NewsFilters['priority'] })}
          className={selectClass}
        >
          <option value="">Todas las prioridades</option>
          {NEWS_PRIORITIES.map((p) => (
            <option key={p} value={p}>
              {NEWS_PRIORITY_LABELS[p]}
            </option>
          ))}
        </select>
        <select
          aria-label="Estado"
          value={filters.status}
          onChange={(e) => updateFilter({ status: e.target.value as NewsFilters['status'] })}
          className={selectClass}
        >
          <option value="">Todos los estados</option>
          {NEWS_STATUSES.map((s) => (
            <option key={s} value={s}>
              {NEWS_STATUS_LABELS[s]}
            </option>
          ))}
        </select>
      </div>

      {/* Primera carga */}
      {isFirstLoad && loading && <Spinner text="Cargando noticias..." />}

      {/* Lista vacía */}
      {isFirstLoad && !loading && !error && !feed.hasMore && (
        <EmptyState message="No hay noticias con estos filtros." />
      )}

      <ul className="space-y-3">
        {feed.items.map((news) => (
          <li key={news.id}>
            <Link
              to={`/news/${news.id}`}
              state={{ fromFeed: true }}
              className="block rounded-lg border border-slate-800 bg-slate-900 p-4 hover:border-amber-400/60"
            >
              <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
                <span className={`rounded-full px-2 py-0.5 ${NEWS_STATUS_COLORS[news.status]}`}>
                  {NEWS_STATUS_LABELS[news.status]}
                </span>
                <span className="rounded-full bg-slate-800 px-2 py-0.5">{NEWS_TYPE_LABELS[news.type]}</span>
                <span className="rounded-full bg-slate-800 px-2 py-0.5">Prioridad {NEWS_PRIORITY_LABELS[news.priority]}</span>
                <span className="text-slate-500">
                  {news.island} · {formatDate(news.publishedAt)}
                </span>
              </div>
              <h2 className="font-semibold">{news.title}</h2>
              <p className="mt-1 text-sm text-slate-400">{news.summary}</p>
            </Link>
          </li>
        ))}
      </ul>

      {/* Error: se muestra DEBAJO de lo ya cargado, sin borrarlo */}
      {error && <ErrorBox message={errorMessage(error)} onRetry={retry} />}

      {/* Cargando más (no es la primera carga) */}
      {!isFirstLoad && loading && <Spinner text="Cargando más noticias..." />}

      {/* Fin de la lista */}
      {!isFirstLoad && !feed.hasMore && !error && (
        <p className="py-4 text-center text-sm text-slate-500">— No hay más noticias —</p>
      )}

      {/* Sentinel del infinite scroll */}
      <div ref={sentinelRef} aria-hidden="true" className="h-1" />
    </div>
  )
}

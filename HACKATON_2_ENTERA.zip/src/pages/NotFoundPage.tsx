import { Link } from 'react-router'

export default function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">
      <p className="text-6xl font-bold text-amber-400">404</p>
      <h1 className="text-xl">Esta isla no aparece en ningún mapa</h1>
      <Link to="/" className="rounded bg-amber-400 px-4 py-2 font-semibold text-slate-900 hover:bg-amber-300">
        Volver al inicio
      </Link>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate, useParams } from 'react-router'
import { apiFetch, ApiError, errorMessage, toApiError } from '../lib/api'
import { useApi } from '../hooks/useApi'
import { ErrorBox, Spinner } from '../components/StatusViews'
import { formatDate, NEWS_PRIORITY_LABELS, NEWS_STATUS_COLORS, NEWS_STATUS_LABELS, NEWS_TYPE_LABELS } from '../lib/format'
import { updateNewsInFeeds } from '../news/newsStore'
import type { NewsDetail } from '../types'

type Verdict = 'CONFIRMED' | 'DEBUNKED'

export default function NewsDetailPage() {
  const { id = '' } = useParams()
  const location = useLocation()
  const navigate = useNavigate()
  const request = useApi<NewsDetail>(`/news/${encodeURIComponent(id)}`)

  // La noticia que mostramos (se actualiza solo cuando el PATCH sale bien).
  const [news, setNews] = useState<NewsDetail | null>(null)
  useEffect(() => {
    if (request.data) {
      setNews(request.data)
      updateNewsInFeeds(request.data) // el feed siempre refleja el estado más reciente
    }
  }, [request.data])

  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState<ApiError | null>(null)
  const [lastVerdict, setLastVerdict] = useState<Verdict | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const verify = async (verdict: Verdict) => {
    if (!news || saving) return
    setSaving(true) // deshabilita los botones mientras la request está en vuelo
    setSaveError(null)
    setSuccess(null)
    setLastVerdict(verdict)
    try {
      const updated = await apiFetch<NewsDetail>(`/news/${encodeURIComponent(news.id)}/status`, {
        method: 'PATCH',
        body: { status: verdict },
      })
      setNews(updated)
      updateNewsInFeeds(updated) // el feed mostrará el nuevo estado al volver
      setSuccess(`Noticia marcada como ${NEWS_STATUS_LABELS[updated.status]}.`)
    } catch (err) {
      // Si falla, NO cambiamos `news`: se conserva el estado anterior.
      const apiError = toApiError(err)
      if (apiError.code === 'NEWS_ALREADY_VERIFIED') request.retry() // traemos el estado real
      setSaveError(apiError)
    } finally {
      setSaving(false)
    }
  }

  const cameFromFeed = (location.state as { fromFeed?: boolean } | null)?.fromFeed === true
  const backButton = cameFromFeed ? (
    <button type="button" onClick={() => navigate(-1)} className="text-amber-400 hover:underline">
      ← Volver al feed
    </button>
  ) : (
    <Link to="/news" className="text-amber-400 hover:underline">
      ← Ir al feed
    </Link>
  )

  return (
    <div className="space-y-4">
      {backButton}

      {request.loading && !news && <Spinner text="Cargando noticia..." />}

      {!request.loading && request.error && !news && (
        <ErrorBox
          message={request.error.status === 404 ? 'Esta noticia no existe.' : errorMessage(request.error)}
          onRetry={request.error.status === 404 ? undefined : request.retry}
        />
      )}

      {news && (
        <article className="space-y-4 rounded-xl border border-slate-800 bg-slate-900 p-6">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className={`rounded-full px-2 py-0.5 ${NEWS_STATUS_COLORS[news.status]}`}>
              {NEWS_STATUS_LABELS[news.status]}
            </span>
            <span className="rounded-full bg-slate-800 px-2 py-0.5">{NEWS_TYPE_LABELS[news.type]}</span>
            <span className="rounded-full bg-slate-800 px-2 py-0.5">Prioridad {NEWS_PRIORITY_LABELS[news.priority]}</span>
          </div>

          <h1 className="text-2xl font-bold">{news.title}</h1>
          <p className="text-sm text-slate-400">
            {news.source} · {news.island} · {formatDate(news.publishedAt)}
            {news.verifiedAt && ` · verificada ${formatDate(news.verifiedAt)}`}
          </p>
          {news.relatedWanted && (
            <p className="text-sm">
              Relacionado:{' '}
              <Link to={`/wanted/${news.relatedWanted.id}`} className="text-amber-400 hover:underline">
                {news.relatedWanted.name}
              </Link>
            </p>
          )}

          <div className="space-y-3 leading-relaxed text-slate-300">
            {news.body.map((paragraph, i) => (
              <p key={i}>{paragraph}</p>
            ))}
          </div>

          {/* Verificar rumor */}
          {news.status === 'RUMOR' && (
            <section className="space-y-3 border-t border-slate-800 pt-4">
              <h2 className="font-semibold">¿Este rumor es cierto?</h2>
              <div className="flex gap-3">
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => verify('CONFIRMED')}
                  className="rounded bg-emerald-500 px-4 py-2 font-semibold text-slate-900 disabled:opacity-50"
                >
                  {saving && lastVerdict === 'CONFIRMED' ? 'Guardando...' : 'Confirmar'}
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => verify('DEBUNKED')}
                  className="rounded bg-slate-500 px-4 py-2 font-semibold text-slate-900 disabled:opacity-50"
                >
                  {saving && lastVerdict === 'DEBUNKED' ? 'Guardando...' : 'Desmentir'}
                </button>
              </div>
            </section>
          )}

          {success && (
            <p role="status" className="rounded bg-emerald-500/15 p-3 text-emerald-300">
              ✓ {success}
            </p>
          )}

          {saveError && (
            <ErrorBox
              message={
                saveError.code === 'NEWS_ALREADY_VERIFIED'
                  ? 'Otra persona ya verificó esta noticia. Mostramos su estado actual.'
                  : `No se pudo guardar: ${errorMessage(saveError)}`
              }
              onRetry={
                saveError.code !== 'NEWS_ALREADY_VERIFIED' && lastVerdict
                  ? () => verify(lastVerdict)
                  : undefined
              }
            />
          )}
        </article>
      )}
    </div>
  )
}

import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useLocation } from 'react-router'
import { useAuth } from '../auth/AuthContext'
import { ApiError } from '../lib/api'

type Field = 'teamName' | 'email' | 'password'
type FieldErrors = Partial<Record<Field, string>>

const FIELDS: Field[] = ['teamName', 'email', 'password']

// Convierte el error del servidor en errores por campo.
function mapServerErrors(error: ApiError): FieldErrors {
  if (error.code === 'EMAIL_ALREADY_REGISTERED') return { email: 'Ese email ya está registrado' }
  if (error.code === 'TEAM_NAME_TAKEN') return { teamName: 'Ese nombre de tripulación ya existe' }

  const result: FieldErrors = {}
  for (const detail of error.details) {
    // el backend puede mandar "email" o "body.email": nos quedamos con la última parte
    const name = detail.field.split('.').pop() ?? ''
    const field = FIELDS.find((f) => f === name)
    if (field && !result[field]) result[field] = detail.message
  }
  return result
}

export default function RegisterPage() {
  const { register } = useAuth()
  const location = useLocation()
  const [values, setValues] = useState<Record<Field, string>>({ teamName: '', email: '', password: '' })
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [generalError, setGeneralError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (field: Field, value: string) => {
    setValues((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setFieldErrors({})
    setGeneralError(null)
    setSubmitting(true)
    try {
      // Si sale bien, la sesión queda iniciada y <PublicOnly> nos manda a la app.
      await register(values.teamName, values.email, values.password)
    } catch (err) {
      if (err instanceof ApiError) {
        const mapped = mapServerErrors(err)
        if (Object.keys(mapped).length > 0) setFieldErrors(mapped)
        else setGeneralError(err.message)
      } else {
        setGeneralError('No se pudo registrar la tripulación')
      }
      setSubmitting(false)
    }
  }

  const inputs: { field: Field; label: string; type: string; autoComplete: string }[] = [
    { field: 'teamName', label: 'Nombre de la tripulación', type: 'text', autoComplete: 'organization' },
    { field: 'email', label: 'Email', type: 'email', autoComplete: 'email' },
    { field: 'password', label: 'Contraseña (mín. 8)', type: 'password', autoComplete: 'new-password' },
  ]

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form onSubmit={handleSubmit} noValidate className="w-full max-w-sm space-y-4 rounded-xl bg-slate-900 p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-amber-400">Registrar tripulación</h1>

        {inputs.map(({ field, label, type, autoComplete }) => (
          <label key={field} className="block">
            <span className="text-sm text-slate-300">{label}</span>
            <input
              type={type}
              value={values[field]}
              onChange={(e) => handleChange(field, e.target.value)}
              autoComplete={autoComplete}
              aria-invalid={Boolean(fieldErrors[field])}
              className={`mt-1 w-full rounded border bg-slate-800 px-3 py-2 ${fieldErrors[field] ? 'border-red-500' : 'border-slate-700'}`}
            />
            {fieldErrors[field] && <span className="mt-1 block text-sm text-red-400">{fieldErrors[field]}</span>}
          </label>
        ))}

        {generalError && (
          <p role="alert" className="text-sm text-red-400">
            {generalError}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded bg-amber-400 py-2 font-semibold text-slate-900 hover:bg-amber-300 disabled:opacity-50"
        >
          {submitting ? 'Registrando...' : 'Registrar y zarpar'}
        </button>

        <p className="text-center text-sm text-slate-400">
          ¿Ya tienen cuenta?{' '}
          <Link to="/login" state={location.state} className="text-amber-400 hover:underline">
            Iniciar sesión
          </Link>
        </p>
      </form>
    </div>
  )
}

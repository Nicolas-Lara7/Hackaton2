import { Link } from 'react-router'
import { useApi } from '../hooks/useApi'
import { EmptyState, ErrorBox, Spinner } from '../components/StatusViews'
import { formatBerries, formatDate, FRUIT_LABELS, STATUS_LABELS } from '../lib/format'
import type { DashboardSummary, FruitFilter, LogPose, WantedStatus } from '../types'

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
      <p className="text-sm text-slate-400">{label}</p>
      <p className="mt-1 text-2xl font-bold">{value}</p>
    </div>
  )
}

function LogPoseCard() {
  const { data, error, loading, retry } = useApi<LogPose>('/log-pose')

  return (
    <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
      <h2 className="mb-3 text-lg font-semibold">Estado del Log Pose</h2>
      {loading && <Spinner />}
      {!loading && error && <ErrorBox message={error.message} onRetry={retry} />}
      {!loading && !error && data && (
        <div className="flex flex-wrap items-center gap-3">
          <span
            className={`rounded-full px-3 py-1 text-sm font-bold ${data.grandLineUnlocked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}
          >
            {data.status === 'UNLOCKED' ? '🔓 Desbloqueado' : '🔒 Bloqueado'}
          </span>
          <span className="text-slate-300">{data.message}</span>
          {data.unlockedAt && <span className="text-sm text-slate-500">desde {formatDate(data.unlockedAt)}</span>}
        </div>
      )}
    </section>
  )
}

function SummarySection() {
  const { data, error, loading, retry } = useApi<DashboardSummary>('/dashboard/summary')

  if (loading) return <Spinner text="Cargando indicadores..." />
  if (error) return <ErrorBox message={error.message} onRetry={retry} />
  if (!data) return null
  if (data.wanted.total === 0) return <EmptyState message="Tu tripulación todavía no tiene carteles registrados." />

  const statuses = Object.keys(STATUS_LABELS) as WantedStatus[]
  const fruits = Object.keys(FRUIT_LABELS) as FruitFilter[]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Carteles" value={data.wanted.total} />
        <StatCard label="Recompensa total" value={formatBerries(data.wanted.totalBounty)} />
        <StatCard label="Recompensa promedio" value={formatBerries(data.wanted.averageBounty)} />
        <StatCard label="Tripulaciones" value={data.crews.total} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
          <h2 className="mb-3 font-semibold">Por estado</h2>
          <ul className="space-y-1">
            {statuses.map((s) => (
              <li key={s} className="flex justify-between">
                <span className="text-slate-400">{STATUS_LABELS[s]}</span>
                <span className="font-mono">{data.wanted.byStatus[s] ?? 0}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
          <h2 className="mb-3 font-semibold">Por fruta del diablo</h2>
          <ul className="space-y-1">
            {fruits.map((f) => (
              <li key={f} className="flex justify-between">
                <span className="text-slate-400">{FRUIT_LABELS[f]}</span>
                <span className="font-mono">{data.wanted.byFruit[f] ?? 0}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      {data.crews.mostWanted && (
        <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
          <h2 className="mb-1 font-semibold">Tripulación más buscada</h2>
          <p>
            {data.crews.mostWanted.name} · {data.crews.mostWanted.shipName} ·{' '}
            {formatBerries(data.crews.mostWanted.totalBounty)}
          </p>
        </section>
      )}

      <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
        <h2 className="mb-3 font-semibold">Top recompensas</h2>
        {data.topBounties.length === 0 ? (
          <p className="text-slate-400">Sin datos.</p>
        ) : (
          <ol className="space-y-2">
            {data.topBounties.map((w) => (
              <li key={w.id} className="flex justify-between gap-4">
                <Link to={`/wanted/${w.id}`} className="hover:text-amber-400">
                  {w.name} <span className="text-slate-500">“{w.epithet}”</span>
                </Link>
                <span className="font-mono">{formatBerries(w.bounty)}</span>
              </li>
            ))}
          </ol>
        )}
      </section>

      <p className="text-xs text-slate-500">Actualizado: {formatDate(data.generatedAt)}</p>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <LogPoseCard />
      <SummarySection />
    </div>
  )
}

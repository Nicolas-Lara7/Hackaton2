import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useLocation } from 'react-router'
import { useAuth } from '../auth/AuthContext'
import { ApiError } from '../lib/api'

export default function LoginPage() {
  const { login } = useAuth()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      // Si sale bien, <PublicOnly> nos lleva a la ruta que se quería abrir.
      await login(email, password)
    } catch (err) {
      if (err instanceof ApiError && err.code === 'INVALID_CREDENTIALS') {
        setError('Email o contraseña incorrectos')
      } else if (err instanceof ApiError) {
        setError(err.message)
      } else {
        setError('No se pudo iniciar sesión')
      }
      setSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form onSubmit={handleSubmit} noValidate className="w-full max-w-sm space-y-4 rounded-xl bg-slate-900 p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-amber-400">Iniciar sesión</h1>

        <label className="block">
          <span className="text-sm text-slate-300">Email</span>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2"
          />
        </label>

        <label className="block">
          <span className="text-sm text-slate-300">Contraseña</span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2"
          />
        </label>

        {error && (
          <p role="alert" className="text-sm text-red-400">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded bg-amber-400 py-2 font-semibold text-slate-900 hover:bg-amber-300 disabled:opacity-50"
        >
          {submitting ? 'Entrando...' : 'Entrar'}
        </button>

        <p className="text-center text-sm text-slate-400">
          ¿No tienen tripulación?{' '}
          {/* Pasamos el state para no perder la ruta a la que se quería ir */}
          <Link to="/register" state={location.state} className="text-amber-400 hover:underline">
            Registrarse
          </Link>
        </p>
      </form>
    </div>
  )
}

# Log Pose Console

Consola de la Guild de Cazarrecompensas (React + TypeScript + Vite + React Router + Tailwind CSS).
Este repositorio cubre el CP1 (Zarpar) y el CP2 (Carteles de "Se Busca").

## Integrantes

| Nombre | Código |
|:-------|:-------|
| _Nombre 1_ | _Código_ |
| _Nombre 2_ | _Código_ |
| _Nombre 3_ | _Código_ |

Equipo: `TEAM-XXX` (el mismo `TEAM_CODE` que va en `hackathon.json`).

## Cómo ejecutar

Requiere Node 24 LTS.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # tsc -b && vite build
```

La URL de la API se lee de `VITE_API_BASE_URL` (archivo `.env`, ver `.env.example`).
No se guardan credenciales en el repositorio.

## Estructura

```txt
src/
  auth/         AuthContext (sesión) y guards de rutas (RequireAuth, PublicOnly)
  components/   UI compartida: formularios, estados, paginación, cartel
  hooks/        useRequest (cancelación + descarte de respuestas tardías)
  layouts/      RootLayout (providers + scroll) y AppLayout (cabecera)
  lib/          api (fetch), services (endpoints), normalize (forma de las respuestas),
                options (enums de filtros), wantedQuery (URL <-> consulta)
  pages/        Login, Registro, Panel, Se busca (lista y detalle), 404
```

## Decisiones clave (para la inspección del CP3)

- **Estado de /wanted en la URL.** `useSearchParams` es la única fuente de verdad: la URL se lee,
  se sanea (valores inválidos se descartan) y se reescribe en forma canónica. Recargar, compartir
  o usar atrás/adelante da la misma vista.
- **Respuestas antiguas.** `useRequest` crea un `AbortController` por petición, cancela la anterior
  al cambiar la consulta y solo entrega datos cuya `key` coincide con la consulta actual.
- **Búsqueda sin una request por tecla.** El texto vive en el input y pasa a la URL 400 ms después
  de la última tecla.
- **Nunca una página inexistente.** Todo cambio que no sea de página vuelve a la página 0; si el
  servidor informa menos páginas que la pedida, se va a la última real.
- **Volver desde el detalle.** El listado guarda una copia en memoria por consulta y el detalle
  vuelve con `navigate(-1)`: mismos filtros, misma página y mismo scroll (`ScrollRestoration`).
- **Sesión.** El token se guarda en `localStorage`; al recargar se verifica con `/auth/me` mientras
  se muestra una pantalla de espera (nunca el login). Un 401 en cualquier ruta privada cierra la
  sesión y devuelve al login, que regresa a la ruta original.

import { Link } from 'react-router-dom';
import { LogPoseMark, btnPrimary } from '../components/ui';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

export function NotFoundPage() {
  useDocumentTitle('Página no encontrada');
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center">
      <LogPoseMark className="h-16 w-16 text-ink" />
      <h1 className="font-display text-5xl">Esta ruta no está en el mapa</h1>
      <p className="max-w-md text-ink-soft">
        La página que buscas no existe o cambió de lugar. Vuelve al panel para retomar el rumbo.
      </p>
      <Link to="/" className={btnPrimary}>
        Volver al panel
      </Link>
    </main>
  );
}

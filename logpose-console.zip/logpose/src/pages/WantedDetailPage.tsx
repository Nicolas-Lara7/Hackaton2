import type { MouseEvent } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { PosterImage, StatusBadge } from '../components/poster';
import { ErrorBlock, Skeleton } from '../components/ui';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { useRequest } from '../hooks/useRequest';
import { createCache } from '../lib/cache';
import { formatBerries, formatDate, readFrom } from '../lib/format';
import { FRUIT_OPTIONS, optionLabel } from '../lib/options';
import { getWanted } from '../lib/services';
import type { WantedPoster } from '../lib/types';

const detailCache = createCache<WantedPoster>(40);

export function WantedDetailPage() {
  const { id = '' } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const from = readFrom(location.state);

  const poster = useRequest((signal) => getWanted(id, signal), `wanted:${id}`, {
    cache: detailCache,
  });
  useDocumentTitle(poster.data?.name ?? 'Cartel');

  // Si se llegó desde el listado, volver es retroceder en el historial: el listado queda como estaba.
  function handleBack(event: MouseEvent<HTMLAnchorElement>) {
    const plainClick =
      event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey;
    if (from && plainClick) {
      event.preventDefault();
      navigate(-1);
    }
  }

  const data = poster.data;
  const facts: Array<{ label: string; value: string }> = [];
  if (data) {
    facts.push({ label: 'Tripulación', value: data.crewName ?? data.crewId ?? '—' });
    facts.push({
      label: 'Fruta del diablo',
      value: data.fruit ? optionLabel(FRUIT_OPTIONS, data.fruit.toUpperCase()) : 'Ninguna',
    });
    facts.push({ label: 'Última actualización', value: formatDate(data.updatedAt) });
    for (const extra of data.extras) facts.push({ label: extra.label, value: extra.value });
  }

  return (
    <div>
      <Link
        to={from ?? '/wanted'}
        onClick={handleBack}
        className="mb-6 inline-block font-semibold text-sea underline"
      >
        Volver a los carteles
      </Link>

      {poster.error && !data ? (
        poster.error.status === 404 ? (
          <ErrorBlock error={poster.error} title="Este cartel no existe" />
        ) : (
          <ErrorBlock
            error={poster.error}
            onRetry={poster.reload}
            title="No pudimos cargar el cartel"
          />
        )
      ) : data ? (
        <article className="grid gap-8 md:grid-cols-[minmax(0,20rem)_1fr]">
          <div className="self-start overflow-hidden rounded-md border-4 border-double border-paper-deep bg-paper p-3">
            <PosterImage poster={data} className="aspect-[4/5] w-full" />
          </div>
          <div>
            <h1 className="font-display text-5xl leading-tight">{data.name}</h1>
            {data.epithet && <p className="mt-1 text-xl italic text-ink-soft">{data.epithet}</p>}
            <p className="mt-4 font-display text-5xl">{formatBerries(data.bounty)}</p>
            <div className="mt-3">
              <StatusBadge status={data.status} />
            </div>
            <dl className="mt-6 grid gap-x-8 gap-y-3 border-t border-line pt-4 sm:grid-cols-2">
              {facts.map((fact) => (
                <div key={fact.label}>
                  <dt className="text-sm text-ink-soft">{fact.label}</dt>
                  <dd className="font-semibold">{fact.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </article>
      ) : (
        <div className="grid gap-8 md:grid-cols-[minmax(0,20rem)_1fr]" aria-busy="true">
          <Skeleton className="aspect-[4/5] w-full" />
          <div className="space-y-4">
            <Skeleton className="h-12 w-2/3" />
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-12 w-1/2" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      )}
    </div>
  );
}

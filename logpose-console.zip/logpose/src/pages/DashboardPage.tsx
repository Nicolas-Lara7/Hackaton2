import { useAuth } from '../auth/AuthContext';
import { EmptyBlock, ErrorBlock, Skeleton } from '../components/ui';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { useRequest } from '../hooks/useRequest';
import { apiOrigin } from '../lib/api';
import { getDashboardSummary, getLogPose } from '../lib/services';

export function DashboardPage() {
  useDocumentTitle('Panel');
  const { user } = useAuth();
  const summary = useRequest((signal) => getDashboardSummary(signal), 'dashboard:summary');
  const logPose = useRequest((signal) => getLogPose(signal), 'dashboard:log-pose');
  const origin = apiOrigin();

  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display text-4xl">Panel de {user?.teamName ?? 'la tripulación'}</h1>
        {user?.teamCode && <p className="text-ink-soft">Código de equipo {user.teamCode}</p>}
      </header>

      <section aria-labelledby="log-pose-title">
        <h2 id="log-pose-title" className="mb-3 font-display text-3xl">
          Log Pose
        </h2>
        {logPose.error ? (
          <ErrorBlock
            error={logPose.error}
            onRetry={logPose.reload}
            title="No pudimos consultar el Log Pose"
          />
        ) : logPose.data ? (
          <div
            className={`rounded-lg border p-5 ${
              logPose.data.unlocked ? 'border-sea/50 bg-sea/10' : 'border-brass/60 bg-brass/10'
            }`}
          >
            <p className="font-display text-3xl">{logPose.data.label}</p>
            <p className="mt-1 text-ink-soft">
              {logPose.data.unlocked
                ? 'El Grand Line está abierto para tu tripulación.'
                : 'Sin Log Pose no puedes entrar al Grand Line. Pide la inspección en Reverse Mountain con la cuenta de tu tripulación.'}
            </p>
            {!logPose.data.unlocked && origin && (
              <a
                href={`${origin}/reverse-mountain`}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-block font-semibold text-sea underline"
              >
                Abrir la cola de inspección
              </a>
            )}
            {logPose.data.details.length > 0 && (
              <dl className="mt-4 grid gap-x-6 gap-y-2 sm:grid-cols-2">
                {logPose.data.details.map((item) => (
                  <div key={item.key}>
                    <dt className="text-sm text-ink-soft">{item.label}</dt>
                    <dd className="font-semibold">{item.value}</dd>
                  </div>
                ))}
              </dl>
            )}
          </div>
        ) : (
          <Skeleton className="h-36" />
        )}
      </section>

      <section aria-labelledby="indicators-title">
        <h2 id="indicators-title" className="mb-3 font-display text-3xl">
          Indicadores de la tripulación
        </h2>
        {summary.error ? (
          <ErrorBlock
            error={summary.error}
            onRetry={summary.reload}
            title="No pudimos cargar los indicadores"
          />
        ) : summary.data ? (
          summary.data.length === 0 ? (
            <EmptyBlock title="Aún no hay indicadores">
              Cuando tu tripulación tenga actividad, sus números aparecerán aquí.
            </EmptyBlock>
          ) : (
            <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {summary.data.map((item) => (
                <div key={item.key} className="rounded-lg border-l-4 border-brass bg-white/70 p-4">
                  <dt className="text-ink-soft">{item.label}</dt>
                  <dd className="font-display text-4xl">{item.value}</dd>
                </div>
              ))}
            </dl>
          )
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true">
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <Skeleton key={index} className="h-24" />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

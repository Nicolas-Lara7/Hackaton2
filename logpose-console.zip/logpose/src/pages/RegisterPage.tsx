import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { AuthShell } from '../components/AuthShell';
import { Field, btnPrimary } from '../components/ui';
import { formErrorsFromApi, isValidEmail } from '../lib/forms';
import type { FormErrors } from '../lib/forms';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

export function RegisterPage() {
  useDocumentTitle('Registrar tripulación');
  const { register } = useAuth();
  const [teamName, setTeamName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;

    const local: FormErrors = {};
    if (!teamName.trim()) local.teamName = 'Ponle un nombre a tu tripulación.';
    if (!email.trim()) local.email = 'Escribe un email para la tripulación.';
    else if (!isValidEmail(email.trim())) local.email = 'Escribe un email válido, como capitan@mugiwara.com.';
    if (!password) local.password = 'Elige una contraseña.';
    setErrors(local);
    if (Object.keys(local).length > 0) return;

    setSubmitting(true);
    try {
      await register(teamName.trim(), email.trim(), password);
    } catch (error) {
      setErrors(formErrorsFromApi(error));
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Registrar tripulación"
      subtitle="Una cuenta por equipo. Los tres integrantes entrarán con el mismo email y contraseña."
      footer={
        <>
          ¿Ya tienes cuenta?{' '}
          <Link to="/login" className="font-semibold text-sea underline">
            Iniciar sesión
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        {errors.form && (
          <p role="alert" className="rounded-md border border-danger/40 bg-danger/10 p-3 text-danger">
            {errors.form}
          </p>
        )}
        <Field
          id="teamName"
          label="Nombre de la tripulación"
          value={teamName}
          onChange={setTeamName}
          error={errors.teamName}
          autoComplete="organization"
          disabled={submitting}
        />
        <Field
          id="email"
          label="Email"
          type="email"
          value={email}
          onChange={setEmail}
          error={errors.email}
          autoComplete="email"
          disabled={submitting}
        />
        <Field
          id="password"
          label="Contraseña"
          type="password"
          value={password}
          onChange={setPassword}
          error={errors.password}
          autoComplete="new-password"
          disabled={submitting}
        />
        <button type="submit" className={`${btnPrimary} w-full`} disabled={submitting}>
          {submitting ? 'Registrando…' : 'Registrar y entrar'}
        </button>
      </form>
    </AuthShell>
  );
}

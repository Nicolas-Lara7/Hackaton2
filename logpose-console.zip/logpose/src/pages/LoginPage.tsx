import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { AuthShell } from '../components/AuthShell';
import { Field, btnPrimary } from '../components/ui';
import { formErrorsFromApi, isValidEmail } from '../lib/forms';
import type { FormErrors } from '../lib/forms';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

export function LoginPage() {
  useDocumentTitle('Iniciar sesión');
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;

    const local: FormErrors = {};
    if (!email.trim()) local.email = 'Escribe el email de tu tripulación.';
    else if (!isValidEmail(email.trim())) local.email = 'Escribe un email válido, como capitan@mugiwara.com.';
    if (!password) local.password = 'Escribe tu contraseña.';
    setErrors(local);
    if (Object.keys(local).length > 0) return;

    setSubmitting(true);
    try {
      await login(email.trim(), password);
    } catch (error) {
      setErrors(formErrorsFromApi(error, 'El email o la contraseña no son correctos.'));
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Iniciar sesión"
      subtitle="Entra con el email y la contraseña de tu tripulación."
      footer={
        <>
          ¿Tu tripulación aún no está registrada?{' '}
          <Link to="/register" className="font-semibold text-sea underline">
            Registrar tripulación
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        {errors.form && (
          <p role="alert" className="rounded-md border border-danger/40 bg-danger/10 p-3 text-danger">
            {errors.form}
          </p>
        )}
        <Field
          id="email"
          label="Email"
          type="email"
          value={email}
          onChange={setEmail}
          error={errors.email}
          autoComplete="email"
          disabled={submitting}
        />
        <Field
          id="password"
          label="Contraseña"
          type="password"
          value={password}
          onChange={setPassword}
          error={errors.password}
          autoComplete="current-password"
          disabled={submitting}
        />
        <button type="submit" className={`${btnPrimary} w-full`} disabled={submitting}>
          {submitting ? 'Entrando…' : 'Entrar'}
        </button>
      </form>
    </AuthShell>
  );
}

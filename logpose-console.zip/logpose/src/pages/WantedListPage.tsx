import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { Pagination } from '../components/Pagination';
import { PosterImage, StatusBadge } from '../components/poster';
import { EmptyBlock, ErrorBlock, btnSecondary, inputClass } from '../components/ui';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { useRequest } from '../hooks/useRequest';
import { createCache } from '../lib/cache';
import { formatBerries } from '../lib/format';
import {
  FRUIT_OPTIONS,
  PAGE_SIZES,
  SORT_OPTIONS,
  STATUS_OPTIONS,
  isPageSize,
  isSortValue,
} from '../lib/options';
import { getCrews, getWantedPage } from '../lib/services';
import type { Crew, WantedPage, WantedPoster, WantedQuery } from '../lib/types';
import { parseWantedQuery, toSearchParams } from '../lib/wantedQuery';

// Copias en memoria: al volver desde un detalle, el listado reaparece al instante tal como estaba.
const wantedCache = createCache<WantedPage>(40);
const crewsCache = createCache<Crew[]>(1);

const SEARCH_DELAY_MS = 400;

function SelectField({
  id,
  label,
  value,
  onChange,
  children,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-semibold">
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className={inputClass}
      >
        {children}
      </select>
    </div>
  );
}

function PosterCard({ poster, from }: { poster: WantedPoster; from: string }) {
  return (
    <li>
      <Link
        to={`/wanted/${encodeURIComponent(poster.id)}`}
        state={{ from }}
        className="block h-full overflow-hidden rounded-md border-2 border-paper-deep bg-paper text-poster-ink shadow-sm hover:border-brass"
      >
        <PosterImage poster={poster} className="aspect-[4/3] w-full sm:aspect-[4/5]" />
        <div className="flex min-h-[9.5rem] flex-col gap-1 p-3">
          <p className="font-display text-2xl leading-tight">{poster.name}</p>
          {poster.epithet && <p className="line-clamp-2 text-sm italic">{poster.epithet}</p>}
          <p className="mt-auto pt-2 font-display text-2xl">{formatBerries(poster.bounty)}</p>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={poster.status} />
            {poster.crewName && <span className="text-sm">{poster.crewName}</span>}
          </div>
        </div>
      </Link>
    </li>
  );
}

function PosterSkeleton() {
  return (
    <li
      aria-hidden="true"
      className="overflow-hidden rounded-md border-2 border-paper-deep/50 bg-paper/50"
    >
      <div className="skeleton aspect-[4/3] w-full rounded-none sm:aspect-[4/5]" />
      <div className="flex min-h-[9.5rem] flex-col gap-2 p-3">
        <div className="skeleton h-6 w-3/4" />
        <div className="skeleton h-4 w-1/2" />
        <div className="skeleton mt-auto h-6 w-2/3" />
        <div className="skeleton h-5 w-1/3" />
      </div>
    </li>
  );
}

export function WantedListPage() {
  useDocumentTitle('Se busca');
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();

  // La URL es la única fuente de verdad; todo valor inválido se descarta al leerla.
  const parsed = useMemo(() => parseWantedQuery(searchParams), [searchParams]);

  const crews = useRequest((signal) => getCrews(signal), 'crews', { cache: crewsCache });
  const crewList = crews.data;
  const crewUnknown =
    parsed.crewId !== '' &&
    crewList !== undefined &&
    !crewList.some((crew) => crew.id === parsed.crewId);
  // Si la URL trae una tripulación, se espera a conocer la lista para no pedir una que no existe.
  const crewPending = parsed.crewId !== '' && crewList === undefined && crews.error === null;

  const query = useMemo<WantedQuery>(
    () => (crewUnknown ? { ...parsed, crewId: '', page: 0 } : parsed),
    [parsed, crewUnknown],
  );
  const queryRef = useRef(query);
  queryRef.current = query;

  const wanted = useRequest((signal) => getWantedPage(query, signal), JSON.stringify(query), {
    enabled: !crewPending,
    cache: wantedCache,
  });
  const data = wanted.data;

  // Deja en la barra de direcciones la forma canónica de lo que realmente se está mostrando.
  const canonical = toSearchParams(query).toString();
  useEffect(() => {
    if (canonical !== searchParams.toString()) {
      setSearchParams(new URLSearchParams(canonical), { replace: true });
    }
  }, [canonical, searchParams, setSearchParams]);

  // Si la página pedida ya no existe (URL manual o menos resultados), va a la última real.
  useEffect(() => {
    if (!data) return;
    const lastPage = Math.max(data.totalPages - 1, 0);
    if (query.page > lastPage) {
      setSearchParams(toSearchParams({ ...queryRef.current, page: lastPage }), { replace: true });
    }
  }, [data, query.page, setSearchParams]);

  const navigateTo = useCallback(
    (patch: Partial<WantedQuery>, replace = false) => {
      // Cualquier cambio que no sea de página vuelve a la página 0.
      const next: WantedQuery = { ...queryRef.current, ...patch, page: patch.page ?? 0 };
      setSearchParams(toSearchParams(next), { replace });
    },
    [setSearchParams],
  );
  const navigateRef = useRef(navigateTo);
  navigateRef.current = navigateTo;

  // Búsqueda: el texto vive en el input y pasa a la URL solo cuando el usuario deja de escribir.
  const [searchText, setSearchText] = useState(query.q);
  const committedQ = useRef(query.q);

  useEffect(() => {
    if (query.q !== committedQ.current) {
      committedQ.current = query.q;
      setSearchText(query.q);
    }
  }, [query.q]);

  useEffect(() => {
    const next = searchText.trim();
    if (next === committedQ.current) return;
    const timer = window.setTimeout(() => {
      committedQ.current = next;
      navigateRef.current({ q: next }, true);
    }, SEARCH_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [searchText]);

  const hasFilters =
    query.q !== '' || query.status !== '' || query.crewId !== '' || query.fruit !== '';

  function clearFilters() {
    committedQ.current = '';
    setSearchText('');
    navigateTo({ q: '', status: '', crewId: '', fruit: '' });
  }

  const from = `${location.pathname}${location.search}`;

  let summary: string;
  if (data) {
    if (data.totalElements === 0) summary = 'Sin resultados';
    else {
      const first = data.page * data.size + 1;
      const last = first + data.content.length - 1;
      summary = `Mostrando ${first}–${last} de ${data.totalElements.toLocaleString('es')} carteles`;
    }
    if (wanted.loading) summary += ' (actualizando…)';
  } else if (wanted.error) summary = 'No se pudieron cargar los carteles';
  else summary = 'Cargando carteles…';

  return (
    <div>
      <header className="mb-6">
        <h1 className="font-display text-4xl">Se busca</h1>
        <p className="text-ink-soft">Los carteles de recompensa de tu workspace.</p>
      </header>

      <form
        role="search"
        aria-label="Buscar y filtrar carteles"
        onSubmit={(event) => event.preventDefault()}
        className="mb-4 grid gap-3 rounded-lg border border-line bg-white/60 p-4 sm:grid-cols-2 lg:grid-cols-4"
      >
        <div className="sm:col-span-2 lg:col-span-4">
          <label htmlFor="q" className="mb-1 block text-sm font-semibold">
            Buscar por nombre o epíteto
          </label>
          <input
            id="q"
            type="search"
            value={searchText}
            maxLength={100}
            onChange={(event) => setSearchText(event.target.value)}
            placeholder="Por ejemplo: Sombrero de Paja"
            className={inputClass}
          />
        </div>

        <SelectField
          id="status"
          label="Estado"
          value={query.status}
          onChange={(value) => navigateTo({ status: value })}
        >
          <option value="">Todos</option>
          {STATUS_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </SelectField>

        <SelectField
          id="crewId"
          label="Tripulación"
          value={query.crewId}
          onChange={(value) => navigateTo({ crewId: value })}
        >
          <option value="">Todas</option>
          {query.crewId !== '' && !crewList?.some((crew) => crew.id === query.crewId) && (
            <option value={query.crewId}>Tripulación {query.crewId}</option>
          )}
          {crewList?.map((crew) => (
            <option key={crew.id} value={crew.id}>
              {crew.name}
            </option>
          ))}
        </SelectField>

        <SelectField
          id="fruit"
          label="Fruta del diablo"
          value={query.fruit}
          onChange={(value) => navigateTo({ fruit: value })}
        >
          <option value="">Todas</option>
          {FRUIT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </SelectField>

        <SelectField
          id="sort"
          label="Ordenar por"
          value={query.sort}
          onChange={(value) => {
            if (isSortValue(value)) navigateTo({ sort: value });
          }}
        >
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </SelectField>
      </form>

      <div className="mb-4 flex min-h-[2.75rem] flex-wrap items-center justify-between gap-3">
        <p role="status" aria-live="polite" className="text-ink-soft">
          {summary}
        </p>
        <div className="flex items-center gap-3">
          {hasFilters && (
            <button type="button" className={btnSecondary} onClick={clearFilters}>
              Limpiar filtros
            </button>
          )}
          <div className="flex items-center gap-2">
            <label htmlFor="size" className="text-sm font-semibold">
              Por página
            </label>
            <select
              id="size"
              value={query.size}
              onChange={(event) => {
                const size = Number(event.target.value);
                if (isPageSize(size)) navigateTo({ size });
              }}
              className={`${inputClass} w-auto!`}
            >
              {PAGE_SIZES.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="min-h-[32rem]" aria-busy={wanted.loading}>
        {wanted.error && !data ? (
          <ErrorBlock
            error={wanted.error}
            onRetry={wanted.reload}
            title="No pudimos cargar los carteles"
          />
        ) : data ? (
          <>
            {wanted.error && (
              <div
                role="alert"
                className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-md border border-danger/40 bg-danger/10 p-3 text-danger"
              >
                <span>No pudimos actualizar el listado. {wanted.error.message}</span>
                <button type="button" className={btnSecondary} onClick={wanted.reload}>
                  Reintentar
                </button>
              </div>
            )}
            {data.content.length === 0 ? (
              hasFilters ? (
                <EmptyBlock title="Ningún cartel coincide">
                  Prueba con otra búsqueda o quita algún filtro.
                  <div className="mt-4">
                    <button type="button" className={btnSecondary} onClick={clearFilters}>
                      Limpiar filtros
                    </button>
                  </div>
                </EmptyBlock>
              ) : (
                <EmptyBlock title="Todavía no hay carteles">
                  Cuando el workspace tenga carteles de “Se busca”, aparecerán aquí.
                </EmptyBlock>
              )
            ) : (
              <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {data.content.map((poster) => (
                  <PosterCard key={poster.id} poster={poster} from={from} />
                ))}
              </ul>
            )}
          </>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Cargando carteles">
            {Array.from({ length: query.size }, (_, index) => (
              <PosterSkeleton key={index} />
            ))}
          </ul>
        )}
      </div>

      <div className="mt-6 min-h-[3rem]">
        {data && (
          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            onChange={(page) => navigateTo({ page })}
          />
        )}
      </div>
    </div>
  );
}

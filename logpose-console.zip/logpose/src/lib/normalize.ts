/**
 * Convierte las respuestas del backend a los tipos de la app.
 * Si el contrato de Swagger usa otros nombres de campo, se corrigen únicamente aquí.
 */
import {
  isRecord,
  pickArray,
  pickBoolean,
  pickNumber,
  pickRecord,
  pickString,
} from './guards';
import type { JsonRecord } from './guards';
import type {
  Crew,
  CrewAccount,
  Indicator,
  LogPoseStatus,
  WantedPage,
  WantedPoster,
  WantedQuery,
} from './types';

export function humanize(key: string): string {
  const spaced = key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .trim()
    .toLowerCase();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

function formatScalar(value: unknown): string | null {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') return Number.isFinite(value) ? value.toLocaleString('es') : '—';
  if (typeof value === 'boolean') return value ? 'Sí' : 'No';
  if (typeof value === 'string') return value;
  return null;
}

function unwrap(data: unknown): unknown {
  if (!isRecord(data)) return data;
  const keys = Object.keys(data);
  if (keys.length === 1) {
    const only = data[keys[0] as string];
    if (isRecord(only)) return only;
  }
  return data;
}

export function toIndicators(
  data: unknown,
  skip: readonly string[] = [],
  depth = 0,
  prefix = '',
): Indicator[] {
  const source = depth === 0 ? unwrap(data) : data;
  if (!isRecord(source)) return [];
  const result: Indicator[] = [];
  for (const [key, value] of Object.entries(source)) {
    if (skip.includes(key)) continue;
    const label = prefix ? `${prefix}: ${humanize(key)}` : humanize(key);
    const scalar = formatScalar(value);
    if (scalar !== null) {
      result.push({ key: `${prefix}${key}`, label, value: scalar });
    } else if (Array.isArray(value)) {
      const scalars = value.map(formatScalar);
      const allScalar = scalars.every((item): item is string => item !== null);
      result.push({
        key: `${prefix}${key}`,
        label,
        value: allScalar && value.length > 0 && value.length <= 6 ? scalars.join(', ') : String(value.length),
      });
    } else if (isRecord(value) && depth < 2) {
      result.push(...toIndicators(value, [], depth + 1, label));
    }
  }
  return result;
}

/* ---------- Sesión ---------- */

export function normalizeAccount(data: unknown): CrewAccount | undefined {
  const root = isRecord(data) ? data : undefined;
  if (!root) return undefined;
  const source =
    pickRecord(root, 'user', 'crew', 'team', 'account', 'me', 'data') ?? root;
  const teamName = pickString(source, 'teamName', 'team_name', 'crewName', 'name', 'team');
  const email = pickString(source, 'email');
  const teamCode = pickString(source, 'teamCode', 'team_code', 'code');
  const id = pickString(source, 'id', 'userId', 'teamId');
  if (!teamName && !email && !teamCode && !id) return undefined;
  return { id, teamName: teamName ?? 'Tripulación', email: email ?? '', teamCode };
}

export function normalizeToken(data: unknown): string | undefined {
  if (!isRecord(data)) return undefined;
  const direct = pickString(data, 'token', 'accessToken', 'access_token', 'jwt', 'jwtToken');
  if (direct) return direct;
  const nested = pickRecord(data, 'data', 'auth', 'session');
  return nested ? pickString(nested, 'token', 'accessToken', 'access_token', 'jwt') : undefined;
}

/* ---------- Dashboard y Log Pose ---------- */

const UNLOCKED_STATUS = ['APPROVED', 'UNLOCKED', 'GRANTED', 'ACTIVE', 'ACTIVATED', 'OBTAINED'];
const LOG_POSE_LABELS: Record<string, string> = {
  LOCKED: 'Sin Log Pose',
  NONE: 'Sin Log Pose',
  PENDING: 'Inspección pendiente',
  QUEUED: 'En la cola de inspección',
  IN_QUEUE: 'En la cola de inspección',
  IN_INSPECTION: 'En inspección',
  REJECTED: 'Inspección no aprobada',
  NOT_APPROVED: 'Inspección no aprobada',
  APPROVED: 'Log Pose obtenido',
  UNLOCKED: 'Log Pose obtenido',
  GRANTED: 'Log Pose obtenido',
  ACTIVE: 'Log Pose obtenido',
};

export function normalizeLogPose(data: unknown): LogPoseStatus {
  const unwrapped = unwrap(data);
  const source: JsonRecord = isRecord(unwrapped) ? unwrapped : {};
  const flag = pickBoolean(
    source,
    'unlocked',
    'approved',
    'hasLogPose',
    'granted',
    'isUnlocked',
    'isApproved',
    'active',
  );
  const status = pickString(source, 'status', 'state');
  const unlocked = flag ?? (status ? UNLOCKED_STATUS.includes(status.toUpperCase()) : false);
  const label =
    (status && LOG_POSE_LABELS[status.toUpperCase()]) ||
    (status ? humanize(status) : unlocked ? 'Log Pose obtenido' : 'Sin Log Pose');
  return {
    unlocked,
    label,
    details: toIndicators(source, [
      'status',
      'state',
      'unlocked',
      'approved',
      'hasLogPose',
      'granted',
      'isUnlocked',
      'isApproved',
      'active',
    ]),
  };
}

/* ---------- Tripulaciones y carteles ---------- */

export function normalizeCrews(data: unknown): Crew[] {
  const list = Array.isArray(data)
    ? data
    : isRecord(data)
      ? pickArray(data, 'content', 'items', 'data', 'crews')
      : undefined;
  if (!list) return [];
  const crews: Crew[] = [];
  for (const item of list) {
    if (!isRecord(item)) continue;
    const id = pickString(item, 'id', 'crewId');
    const name = pickString(item, 'name', 'crewName', 'teamName');
    if (id) crews.push({ id, name: name ?? `Tripulación ${id}` });
  }
  return crews;
}

const POSTER_KEYS = [
  'id', 'wantedId', 'posterId',
  'name', 'pirateName', 'fullName',
  'epithet', 'alias', 'nickname', 'title',
  'bounty', 'reward', 'amount',
  'status',
  'crew', 'crewId', 'crewName',
  'fruit', 'fruitType', 'devilFruit', 'devilFruitType',
  'imageUrl', 'image', 'posterUrl', 'photoUrl', 'picture', 'avatar',
  'updatedAt',
];

export function normalizePoster(data: unknown): WantedPoster | undefined {
  const source = isRecord(data) ? (pickRecord(data, 'wanted', 'poster') ?? data) : undefined;
  if (!source) return undefined;
  const id = pickString(source, 'id', 'wantedId', 'posterId');
  if (!id) return undefined;

  const crew = pickRecord(source, 'crew');
  const fruitRecord = pickRecord(source, 'devilFruit', 'fruit');
  const fruit =
    pickString(source, 'fruitType', 'devilFruitType', 'fruit', 'devilFruit') ??
    (fruitRecord ? pickString(fruitRecord, 'type', 'fruitType', 'name') : undefined);

  const extras = toIndicators(source, POSTER_KEYS).filter(
    (item) => !/^https?:\/\//i.test(item.value),
  );

  return {
    id,
    name: pickString(source, 'name', 'pirateName', 'fullName') ?? `Cartel ${id}`,
    epithet: pickString(source, 'epithet', 'alias', 'nickname', 'title'),
    bounty: pickNumber(source, 'bounty', 'reward', 'amount'),
    status: pickString(source, 'status'),
    crewId: (crew ? pickString(crew, 'id') : undefined) ?? pickString(source, 'crewId'),
    crewName: (crew ? pickString(crew, 'name') : undefined) ?? pickString(source, 'crewName'),
    fruit,
    imageUrl: pickString(source, 'imageUrl', 'image', 'posterUrl', 'photoUrl', 'picture', 'avatar'),
    updatedAt: pickString(source, 'updatedAt'),
    extras,
  };
}

export function normalizeWantedPage(data: unknown, requested: WantedQuery): WantedPage {
  const source = isRecord(data) ? data : {};
  const list = pickArray(source, 'content', 'items', 'data') ?? (Array.isArray(data) ? data : []);
  const content: WantedPoster[] = [];
  for (const item of list) {
    const poster = normalizePoster(item);
    if (poster) content.push(poster);
  }
  const totalElements = pickNumber(source, 'totalElements', 'total') ?? content.length;
  const size = pickNumber(source, 'size') ?? requested.size;
  const totalPages = pickNumber(source, 'totalPages') ?? Math.ceil(totalElements / Math.max(size, 1));
  return {
    content,
    totalElements,
    totalPages,
    page: pickNumber(source, 'page', 'number') ?? requested.page,
    size,
  };
}

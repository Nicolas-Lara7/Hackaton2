export function formatBerries(value: number | undefined): string {
  if (value === undefined) return 'Sin recompensa';
  return `฿ ${value.toLocaleString('en-US')}`;
}

export function formatDate(value: string | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('es', { dateStyle: 'medium' });
}

export function readFrom(state: unknown): string | null {
  if (typeof state !== 'object' || state === null || !('from' in state)) return null;
  const from = (state as { from: unknown }).from;
  if (typeof from !== 'string' || !from.startsWith('/') || from.startsWith('//')) return null;
  return from;
}

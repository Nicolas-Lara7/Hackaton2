import { isRecord, pickString } from './guards';

const TOKEN_KEY = 'logpose.token';

export const tokenStore = {
  get(): string | null {
    try {
      return window.localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  },
  set(token: string): void {
    try {
      window.localStorage.setItem(TOKEN_KEY, token);
    } catch {
      /* almacenamiento no disponible */
    }
  },
  clear(): void {
    try {
      window.localStorage.removeItem(TOKEN_KEY);
    } catch {
      /* almacenamiento no disponible */
    }
  },
};

export class ApiError extends Error {
  readonly status: number;
  readonly code: string | undefined;
  readonly fieldErrors: Record<string, string>;

  constructor(
    message: string,
    status: number,
    code?: string,
    fieldErrors: Record<string, string> = {},
  ) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error;
  return new ApiError(
    error instanceof Error ? error.message : 'Ocurrió un error inesperado.',
    0,
    'UNKNOWN',
  );
}

export function apiBaseUrl(): string {
  const raw: unknown = import.meta.env.VITE_API_BASE_URL;
  if (typeof raw !== 'string' || raw.trim() === '') {
    throw new ApiError('Falta definir VITE_API_BASE_URL en el archivo .env.', 0, 'CONFIG');
  }
  return raw.trim().replace(/\/+$/, '');
}

export function apiOrigin(): string | null {
  try {
    return new URL(apiBaseUrl()).origin;
  } catch {
    return null;
  }
}

let unauthorizedHandler: (() => void) | null = null;

/** El AuthProvider registra aquí qué hacer cuando el servidor responde 401 a una ruta privada. */
export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler;
}

type Primitive = string | number | undefined | null;

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  body?: unknown;
  params?: Record<string, Primitive>;
  signal?: AbortSignal;
  /** false para login y registro: un 401 ahí significa credenciales inválidas, no sesión vencida. */
  auth?: boolean;
}

function defaultMessage(status: number): string {
  switch (status) {
    case 0:
      return 'No se pudo conectar con el servidor. Revisa tu conexión e intenta de nuevo.';
    case 400:
    case 422:
      return 'Los datos enviados no son válidos.';
    case 401:
      return 'Tu sesión no es válida o ya expiró. Inicia sesión de nuevo.';
    case 403:
      return 'No tienes permiso para hacer esto.';
    case 404:
      return 'No encontramos lo que buscabas.';
    case 409:
      return 'Ya existe un registro con esos datos.';
    case 423:
      return 'Necesitas el Log Pose para entrar al Grand Line.';
    case 429:
      return 'Demasiadas solicitudes. Espera un momento e intenta de nuevo.';
    default:
      return status >= 500
        ? 'El servidor tuvo un problema. Intenta de nuevo en unos segundos.'
        : `La solicitud falló (error ${status}).`;
  }
}

const IGNORED_FIELD_KEYS = ['message', 'code', 'status', 'error', 'timestamp', 'path', 'type', 'title'];

function collectFields(source: unknown, into: Record<string, string>): void {
  if (Array.isArray(source)) {
    for (const item of source) {
      if (!isRecord(item)) continue;
      const loc = Array.isArray(item.loc)
        ? item.loc.filter((part): part is string => typeof part === 'string')
        : [];
      const field =
        pickString(item, 'field', 'name', 'param', 'path', 'property') ?? loc[loc.length - 1];
      const message = pickString(item, 'message', 'msg', 'reason', 'error', 'defaultMessage');
      if (field && message) {
        const key = field.split('.').pop() ?? field;
        if (!(key in into)) into[key] = message;
      }
    }
  } else if (isRecord(source)) {
    for (const [key, value] of Object.entries(source)) {
      if (IGNORED_FIELD_KEYS.includes(key) || key in into) continue;
      if (typeof value === 'string') into[key] = value;
      else if (Array.isArray(value) && typeof value[0] === 'string') into[key] = value[0];
    }
  }
}

function guessFieldFromConflict(code: string | undefined, message: string): string | null {
  const text = `${code ?? ''} ${message}`.toLowerCase();
  if (/e-?mail|correo/.test(text)) return 'email';
  if (/team|equipo|crew|tripulaci|nombre|name/.test(text)) return 'teamName';
  return null;
}

function parseApiError(status: number, data: unknown): ApiError {
  const root = isRecord(data) ? data : {};
  const inner = isRecord(root.error) ? root.error : root;

  const code = pickString(inner, 'code', 'errorCode') ?? pickString(root, 'code', 'errorCode');
  let message = pickString(inner, 'message') ?? pickString(root, 'message', 'title');
  if (!message && typeof root.error === 'string') message = root.error;
  if (!message && typeof root.detail === 'string') message = root.detail;
  if (!message && typeof data === 'string' && data.length < 200) message = data;

  const fields: Record<string, string> = {};
  collectFields(root.errors, fields);
  collectFields(root.fieldErrors, fields);
  collectFields(root.details, fields);
  collectFields(inner.details, fields);
  collectFields(inner.errors, fields);
  collectFields(inner.fieldErrors, fields);
  collectFields(root.detail, fields);

  const looksLikeConflict =
    status === 409 || /EXIST|TAKEN|DUPLICATE|ALREADY|REGISTERED|CONFLICT/i.test(code ?? '');
  if (Object.keys(fields).length === 0 && looksLikeConflict) {
    const guessed = guessFieldFromConflict(code, message ?? '');
    if (guessed) fields[guessed] = message ?? defaultMessage(409);
  }

  return new ApiError(message ?? defaultMessage(status), status, code, fields);
}

export async function request(path: string, options: RequestOptions = {}): Promise<unknown> {
  const { method = 'GET', body, params, signal, auth = true } = options;

  const query = new URLSearchParams();
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== '') query.set(key, String(value));
    }
  }
  const queryString = query.toString();
  const url = `${apiBaseUrl()}${path}${queryString ? `?${queryString}` : ''}`;

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const token = tokenStore.get();
  if (auth && token) headers.Authorization = `Bearer ${token}`;

  let response: Response;
  let text: string;
  try {
    response = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    });
    text = await response.text();
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error;
    throw new ApiError(defaultMessage(0), 0, 'NETWORK');
  }

  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!response.ok) {
    const error = parseApiError(response.status, data);
    if (response.status === 401 && auth && unauthorizedHandler) unauthorizedHandler();
    throw error;
  }
  return data;
}

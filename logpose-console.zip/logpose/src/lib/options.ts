/**
 * Opciones de filtros y orden de /wanted.
 *
 * IMPORTANTE: los valores de STATUS_OPTIONS y FRUIT_OPTIONS deben coincidir con los enums que
 * documenta Swagger (GET /wanted). Si difieren, ajústalos aquí: es el único lugar.
 */
export const PAGE_SIZES = [10, 20, 50] as const;
export type PageSize = (typeof PAGE_SIZES)[number];
export const DEFAULT_SIZE: PageSize = 10;

export const SORT_OPTIONS = [
  { value: 'bounty,desc', label: 'Mayor recompensa' },
  { value: 'name,asc', label: 'Nombre, de A a Z' },
  { value: 'updatedAt,desc', label: 'Actualizados primero' },
] as const;
export type SortValue = (typeof SORT_OPTIONS)[number]['value'];
export const DEFAULT_SORT: SortValue = 'bounty,desc';

export interface Option {
  value: string;
  label: string;
}

export const STATUS_OPTIONS: readonly Option[] = [
  { value: 'ACTIVE', label: 'Activo' },
  { value: 'CAPTURED', label: 'Capturado' },
  { value: 'DEFEATED', label: 'Derrotado' },
  { value: 'DECEASED', label: 'Fallecido' },
  { value: 'MISSING', label: 'Desaparecido' },
];

export const FRUIT_OPTIONS: readonly Option[] = [
  { value: 'PARAMECIA', label: 'Paramecia' },
  { value: 'LOGIA', label: 'Logia' },
  { value: 'ZOAN', label: 'Zoan' },
  { value: 'ANCIENT_ZOAN', label: 'Zoan antigua' },
  { value: 'MYTHICAL_ZOAN', label: 'Zoan mítica' },
];

export function isPageSize(value: number): value is PageSize {
  return (PAGE_SIZES as readonly number[]).includes(value);
}

export function isSortValue(value: string): value is SortValue {
  return SORT_OPTIONS.some((option) => option.value === value);
}

/** Devuelve el valor canónico de la opción, o '' si el texto no corresponde a ninguna. */
export function matchOption(options: readonly Option[], raw: string | null): string {
  if (!raw) return '';
  const upper = raw.trim().toUpperCase();
  return options.find((option) => option.value === upper)?.value ?? '';
}

export function optionLabel(options: readonly Option[], value: string): string {
  return options.find((option) => option.value === value)?.label ?? value;
}

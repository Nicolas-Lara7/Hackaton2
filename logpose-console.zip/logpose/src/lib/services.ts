import { ApiError, request } from './api';
import {
  normalizeAccount,
  normalizeCrews,
  normalizeLogPose,
  normalizePoster,
  normalizeToken,
  normalizeWantedPage,
  toIndicators,
} from './normalize';
import { toApiParams } from './wantedQuery';
import type {
  Crew,
  CrewAccount,
  Indicator,
  LogPoseStatus,
  WantedPage,
  WantedPoster,
  WantedQuery,
} from './types';

export interface AuthResult {
  token: string;
  account?: CrewAccount;
}

function toAuthResult(data: unknown): AuthResult {
  const token = normalizeToken(data);
  if (!token) {
    throw new ApiError('El servidor no devolvió un token de sesión.', 0, 'BAD_RESPONSE');
  }
  return { token, account: normalizeAccount(data) };
}

export async function loginRequest(email: string, password: string): Promise<AuthResult> {
  const data = await request('/auth/login', { method: 'POST', body: { email, password }, auth: false });
  return toAuthResult(data);
}

export async function registerRequest(
  teamName: string,
  email: string,
  password: string,
): Promise<AuthResult> {
  const data = await request('/auth/register', {
    method: 'POST',
    body: { teamName, email, password },
    auth: false,
  });
  if (normalizeToken(data)) return toAuthResult(data);
  // Si el registro no devuelve token, se inicia sesión con las mismas credenciales.
  const session = await loginRequest(email, password);
  return { token: session.token, account: normalizeAccount(data) ?? session.account };
}

export async function fetchMe(signal?: AbortSignal): Promise<CrewAccount | undefined> {
  return normalizeAccount(await request('/auth/me', { signal }));
}

export async function getDashboardSummary(signal: AbortSignal): Promise<Indicator[]> {
  return toIndicators(await request('/dashboard/summary', { signal }));
}

export async function getLogPose(signal: AbortSignal): Promise<LogPoseStatus> {
  return normalizeLogPose(await request('/log-pose', { signal }));
}

export async function getCrews(signal: AbortSignal): Promise<Crew[]> {
  return normalizeCrews(await request('/crews', { signal }));
}

export async function getWantedPage(query: WantedQuery, signal: AbortSignal): Promise<WantedPage> {
  const data = await request('/wanted', { params: toApiParams(query), signal });
  return normalizeWantedPage(data, query);
}

export async function getWanted(id: string, signal: AbortSignal): Promise<WantedPoster> {
  const data = await request(`/wanted/${encodeURIComponent(id)}`, { signal });
  const poster = normalizePoster(data);
  if (!poster) throw new ApiError('La respuesta del cartel no tiene el formato esperado.', 0, 'BAD_RESPONSE');
  return poster;
}

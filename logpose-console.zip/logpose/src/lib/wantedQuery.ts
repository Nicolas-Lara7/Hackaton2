import {
  DEFAULT_SIZE,
  DEFAULT_SORT,
  FRUIT_OPTIONS,
  STATUS_OPTIONS,
  isPageSize,
  isSortValue,
  matchOption,
} from './options';
import type { WantedQuery } from './types';

export const DEFAULT_QUERY: WantedQuery = {
  page: 0,
  size: DEFAULT_SIZE,
  sort: DEFAULT_SORT,
  q: '',
  status: '',
  crewId: '',
  fruit: '',
};

const MAX_PAGE = 100000;

/** Lee la URL y descarta cualquier valor inválido: la vista nunca recibe datos rotos. */
export function parseWantedQuery(params: URLSearchParams): WantedQuery {
  const rawPage = Number(params.get('page'));
  const page = Number.isInteger(rawPage) && rawPage >= 0 && rawPage <= MAX_PAGE ? rawPage : 0;

  const rawSize = Number(params.get('size'));
  const size = isPageSize(rawSize) ? rawSize : DEFAULT_QUERY.size;

  const rawSort = params.get('sort') ?? '';
  const sort = isSortValue(rawSort) ? rawSort : DEFAULT_QUERY.sort;

  const crewId = params.get('crewId') ?? '';

  return {
    page,
    size,
    sort,
    q: (params.get('q') ?? '').trim().slice(0, 100),
    status: matchOption(STATUS_OPTIONS, params.get('status')),
    fruit: matchOption(FRUIT_OPTIONS, params.get('fruit')),
    crewId: /^[\w-]{1,64}$/.test(crewId) ? crewId : '',
  };
}

/** Forma canónica de la URL: solo lo que se aparta de los valores por defecto. */
export function toSearchParams(query: WantedQuery): URLSearchParams {
  const params = new URLSearchParams();
  if (query.q) params.set('q', query.q);
  if (query.status) params.set('status', query.status);
  if (query.crewId) params.set('crewId', query.crewId);
  if (query.fruit) params.set('fruit', query.fruit);
  if (query.sort !== DEFAULT_QUERY.sort) params.set('sort', query.sort);
  if (query.size !== DEFAULT_QUERY.size) params.set('size', String(query.size));
  if (query.page > 0) params.set('page', String(query.page));
  return params;
}

export function toApiParams(query: WantedQuery): Record<string, string | number> {
  const params: Record<string, string | number> = {
    page: query.page,
    size: query.size,
    sort: query.sort,
  };
  if (query.q) params.q = query.q;
  if (query.status) params.status = query.status;
  if (query.crewId) params.crewId = query.crewId;
  if (query.fruit) params.fruit = query.fruit;
  return params;
}

import { toApiError } from './api';

export type FieldName = 'teamName' | 'email' | 'password';
export type FormErrors = Partial<Record<FieldName | 'form', string>>;

const ALIASES: Record<string, FieldName> = {
  teamname: 'teamName',
  crewname: 'teamName',
  team: 'teamName',
  name: 'teamName',
  email: 'email',
  mail: 'email',
  password: 'password',
  pass: 'password',
};

/** Reparte los errores del servidor: cada uno junto al campo que corresponde; el resto, arriba. */
export function formErrorsFromApi(
  error: unknown,
  credentialsMessage?: string,
): FormErrors {
  const apiError = toApiError(error);
  const errors: FormErrors = {};
  for (const [key, message] of Object.entries(apiError.fieldErrors)) {
    const field = ALIASES[key.replace(/[_-]/g, '').toLowerCase()];
    if (field && !errors[field]) errors[field] = message;
  }
  if (Object.keys(errors).length === 0) {
    errors.form =
      apiError.status === 401 && credentialsMessage ? credentialsMessage : apiError.message;
  }
  return errors;
}

export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

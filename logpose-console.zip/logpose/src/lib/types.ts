import type { PageSize, SortValue } from './options';

export interface CrewAccount {
  id?: string;
  teamName: string;
  email: string;
  teamCode?: string;
}

export interface Indicator {
  key: string;
  label: string;
  value: string;
}

export interface LogPoseStatus {
  unlocked: boolean;
  label: string;
  details: Indicator[];
}

export interface Crew {
  id: string;
  name: string;
}

export interface WantedPoster {
  id: string;
  name: string;
  epithet?: string;
  bounty?: number;
  status?: string;
  crewId?: string;
  crewName?: string;
  fruit?: string;
  imageUrl?: string;
  updatedAt?: string;
  extras: Indicator[];
}

export interface WantedPage {
  content: WantedPoster[];
  totalElements: number;
  totalPages: number;
  page: number;
  size: number;
}

export interface WantedQuery {
  page: number;
  size: PageSize;
  sort: SortValue;
  q: string;
  status: string;
  crewId: string;
  fruit: string;
}

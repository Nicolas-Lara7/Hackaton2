export interface Cache<T> {
  get(key: string): T | undefined;
  set(key: string, value: T): void;
}

const clearers: Array<() => void> = [];

/** Caché en memoria muy simple. Se vacía al cerrar sesión para no mezclar tripulaciones. */
export function createCache<T>(limit = 40): Cache<T> {
  const store = new Map<string, T>();
  clearers.push(() => store.clear());
  return {
    get: (key) => store.get(key),
    set: (key, value) => {
      store.delete(key);
      store.set(key, value);
      if (store.size > limit) {
        const oldest = store.keys().next();
        if (!oldest.done) store.delete(oldest.value);
      }
    },
  };
}

export function clearAllCaches(): void {
  clearers.forEach((clear) => clear());
}

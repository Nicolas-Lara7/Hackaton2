import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { ApiError, setUnauthorizedHandler, tokenStore } from '../lib/api';
import { clearAllCaches } from '../lib/cache';
import { fetchMe, loginRequest, registerRequest } from '../lib/services';
import type { AuthResult } from '../lib/services';
import type { CrewAccount } from '../lib/types';

type AuthStatus = 'checking' | 'authenticated' | 'anonymous' | 'unavailable';

interface AuthContextValue {
  status: AuthStatus;
  user: CrewAccount | null;
  login: (email: string, password: string) => Promise<void>;
  register: (teamName: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  retry: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function mergeAccounts(primary?: CrewAccount, fallback?: CrewAccount): CrewAccount | null {
  if (!primary && !fallback) return null;
  return {
    id: primary?.id ?? fallback?.id,
    teamName: primary?.teamName ?? fallback?.teamName ?? 'Tripulación',
    email: primary?.email || fallback?.email || '',
    teamCode: primary?.teamCode ?? fallback?.teamCode,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>(() =>
    tokenStore.get() ? 'checking' : 'anonymous',
  );
  const [user, setUser] = useState<CrewAccount | null>(null);
  const [attempt, setAttempt] = useState(0);

  const endSession = useCallback(() => {
    tokenStore.clear();
    clearAllCaches();
    setUser(null);
    setStatus('anonymous');
  }, []);

  // Si el servidor rechaza el token en cualquier ruta privada, se vuelve al login.
  useEffect(() => {
    setUnauthorizedHandler(endSession);
    return () => setUnauthorizedHandler(null);
  }, [endSession]);

  // Restaura la sesión al cargar la app (y al reintentar).
  useEffect(() => {
    if (!tokenStore.get()) return;
    const controller = new AbortController();
    fetchMe(controller.signal)
      .then((account) => {
        if (controller.signal.aborted) return;
        setUser(mergeAccounts(account));
        setStatus('authenticated');
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        if (error instanceof ApiError && error.status === 401) endSession();
        else setStatus('unavailable');
      });
    return () => controller.abort();
  }, [attempt, endSession]);

  const startSession = useCallback(async (result: AuthResult) => {
    tokenStore.set(result.token);
    try {
      const account = await fetchMe();
      setUser(mergeAccounts(account, result.account));
      setStatus('authenticated');
    } catch (error) {
      tokenStore.clear();
      throw error;
    }
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      await startSession(await loginRequest(email, password));
    },
    [startSession],
  );

  const register = useCallback(
    async (teamName: string, email: string, password: string) => {
      await startSession(await registerRequest(teamName, email, password));
    },
    [startSession],
  );

  const retry = useCallback(() => {
    setStatus('checking');
    setAttempt((value) => value + 1);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ status, user, login, register, logout: endSession, retry }),
    [status, user, login, register, endSession, retry],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return context;
}

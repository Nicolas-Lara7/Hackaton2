import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { SplashScreen } from '../components/ui';
import { readFrom } from '../lib/format';
import { useAuth } from './AuthContext';

/** Rutas privadas: sin sesión se manda al login recordando a dónde quería ir. */
export function RequireAuth() {
  const { status, retry } = useAuth();
  const location = useLocation();

  if (status === 'checking') return <SplashScreen message="Verificando tu sesión…" />;
  if (status === 'unavailable') {
    return (
      <SplashScreen
        message="No pudimos verificar tu sesión. Revisa tu conexión e intenta de nuevo."
        onRetry={retry}
      />
    );
  }
  if (status === 'anonymous') {
    const from = `${location.pathname}${location.search}${location.hash}`;
    return <Navigate to="/login" replace state={{ from }} />;
  }
  return <Outlet />;
}

/** Login y registro: con sesión activa no tienen sentido, se vuelve a donde se iba. */
export function PublicOnly() {
  const { status, retry } = useAuth();
  const location = useLocation();

  if (status === 'checking') return <SplashScreen message="Verificando tu sesión…" />;
  if (status === 'unavailable') {
    return (
      <SplashScreen
        message="No pudimos verificar tu sesión. Revisa tu conexión e intenta de nuevo."
        onRetry={retry}
      />
    );
  }
  if (status === 'authenticated') {
    const from = readFrom(location.state);
    const target = from && !/^\/(login|register)(\/|\?|$)/.test(from) ? from : '/';
    return <Navigate to={target} replace />;
  }
  return <Outlet />;
}

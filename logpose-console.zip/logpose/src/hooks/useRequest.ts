import { useCallback, useEffect, useRef, useState } from 'react';
import { toApiError } from '../lib/api';
import type { ApiError } from '../lib/api';
import type { Cache } from '../lib/cache';

interface State<T> {
  dataKey: string | null;
  data: T | undefined;
  errorKey: string | null;
  error: ApiError | null;
  loading: boolean;
}

interface Options<T> {
  enabled?: boolean;
  cache?: Cache<T>;
}

export interface RequestResult<T> {
  /** Solo se entrega data que corresponde exactamente a la `key` actual (o su copia en caché). */
  data: T | undefined;
  error: ApiError | null;
  loading: boolean;
  reload: () => void;
}

/**
 * Pide datos cada vez que cambia `key`. Cancela la petición anterior y descarta cualquier
 * respuesta que llegue tarde, así que lo que se muestra siempre es lo último que se pidió.
 */
export function useRequest<T>(
  fetcher: (signal: AbortSignal) => Promise<T>,
  key: string,
  options: Options<T> = {},
): RequestResult<T> {
  const { enabled = true, cache } = options;
  const [state, setState] = useState<State<T>>({
    dataKey: null,
    data: undefined,
    errorKey: null,
    error: null,
    loading: enabled,
  });
  const [attempt, setAttempt] = useState(0);

  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;
  const cacheRef = useRef(cache);
  cacheRef.current = cache;

  useEffect(() => {
    if (!enabled) return;
    const controller = new AbortController();
    setState((previous) => ({ ...previous, loading: true, error: null, errorKey: null }));

    fetcherRef
      .current(controller.signal)
      .then((data) => {
        if (controller.signal.aborted) return;
        cacheRef.current?.set(key, data);
        setState({ dataKey: key, data, errorKey: null, error: null, loading: false });
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setState((previous) => ({
          ...previous,
          errorKey: key,
          error: toApiError(error),
          loading: false,
        }));
      });

    return () => controller.abort();
  }, [key, attempt, enabled]);

  const reload = useCallback(() => setAttempt((value) => value + 1), []);

  const data = state.dataKey === key ? state.data : cache?.get(key);
  const error = state.errorKey === key ? state.error : null;
  const loading = enabled && error === null && (state.loading || state.dataKey !== key);

  return { data, error, loading, reload };
}

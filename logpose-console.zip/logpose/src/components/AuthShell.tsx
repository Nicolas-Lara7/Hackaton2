import type { ReactNode } from 'react';
import { LogPoseMark } from './ui';

export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-3">
          <LogPoseMark className="h-12 w-12 text-ink" />
          <span className="font-display text-3xl">Log Pose Console</span>
        </div>
        <div className="rounded-xl border border-line bg-white/80 p-6 shadow-sm">
          <h1 className="font-display text-4xl">{title}</h1>
          <p className="mb-5 mt-1 text-ink-soft">{subtitle}</p>
          {children}
        </div>
        <p className="mt-4 text-center text-ink-soft">{footer}</p>
      </div>
    </main>
  );
}

import type { ReactNode } from 'react';
import type { ApiError } from '../lib/api';

export const btnPrimary =
  'inline-flex items-center justify-center rounded-md bg-ink px-4 py-2 font-semibold text-chart hover:bg-sea disabled:cursor-not-allowed disabled:opacity-60';
export const btnSecondary =
  'inline-flex items-center justify-center rounded-md border border-ink/30 bg-white/70 px-4 py-2 font-semibold text-ink hover:bg-white disabled:cursor-not-allowed disabled:opacity-60';
export const inputClass =
  'w-full rounded-md border border-ink/30 bg-white px-3 py-2 text-ink placeholder:text-ink-soft/70 disabled:opacity-60';

export function LogPoseMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={className}>
      <circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M16 5l4 11h-8z" fill="var(--color-brass)" />
      <path d="M16 27l4-11h-8z" fill="currentColor" opacity="0.55" />
      <circle cx="16" cy="16" r="1.8" fill="currentColor" />
    </svg>
  );
}

export function SplashScreen({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center">
      <LogPoseMark className="h-14 w-14 text-ink" />
      <p role="status" className="text-lg text-ink-soft">
        {message}
      </p>
      {onRetry && (
        <button type="button" className={btnPrimary} onClick={onRetry}>
          Reintentar
        </button>
      )}
    </div>
  );
}

export function ErrorBlock({
  error,
  onRetry,
  title = 'No pudimos cargar esto',
}: {
  error: ApiError;
  onRetry?: () => void;
  title?: string;
}) {
  return (
    <div
      role="alert"
      className="flex min-h-[16rem] flex-col items-center justify-center rounded-lg border border-danger/40 bg-white/70 p-6 text-center"
    >
      <p className="font-display text-3xl text-danger">{title}</p>
      <p className="mt-1 max-w-prose text-ink-soft">{error.message}</p>
      {onRetry && (
        <button type="button" className={`${btnPrimary} mt-4`} onClick={onRetry}>
          Reintentar
        </button>
      )}
    </div>
  );
}

export function EmptyBlock({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="flex min-h-[16rem] flex-col items-center justify-center rounded-lg border border-dashed border-ink/30 bg-white/40 p-6 text-center">
      <p className="font-display text-3xl">{title}</p>
      {children && <div className="mt-2 max-w-prose text-ink-soft">{children}</div>}
    </div>
  );
}

interface FieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  error?: string;
  autoComplete?: string;
  disabled?: boolean;
}

export function Field({
  id,
  label,
  value,
  onChange,
  type = 'text',
  error,
  autoComplete,
  disabled,
}: FieldProps) {
  const errorId = `${id}-error`;
  return (
    <div>
      <label htmlFor={id} className="mb-1 block font-semibold">
        {label}
      </label>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        autoComplete={autoComplete}
        disabled={disabled}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className={`${inputClass} ${error ? 'border-danger' : ''}`}
      />
      {error && (
        <p id={errorId} className="mt-1 text-sm font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  );
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div aria-hidden="true" className={`skeleton ${className}`} />;
}

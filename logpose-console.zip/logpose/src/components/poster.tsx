import { useState } from 'react';
import { STATUS_OPTIONS, optionLabel } from '../lib/options';
import type { WantedPoster } from '../lib/types';

const STATUS_STYLES: Record<string, string> = {
  ACTIVE: 'bg-sea/15 text-sea',
  CAPTURED: 'bg-brass/25 text-poster-ink',
  DEFEATED: 'bg-danger/15 text-danger',
  DECEASED: 'bg-danger/15 text-danger',
};

export function StatusBadge({ status }: { status: string | undefined }) {
  if (!status) return null;
  const style = STATUS_STYLES[status.toUpperCase()] ?? 'bg-ink/10 text-ink';
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-sm font-semibold ${style}`}>
      {optionLabel(STATUS_OPTIONS, status.toUpperCase())}
    </span>
  );
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('');
}

export function PosterImage({ poster, className = '' }: { poster: WantedPoster; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (poster.imageUrl && !failed) {
    return (
      <img
        src={poster.imageUrl}
        alt={`Retrato de ${poster.name}`}
        loading="lazy"
        onError={() => setFailed(true)}
        className={`object-cover sepia-[.3] ${className}`}
      />
    );
  }
  return (
    <div
      aria-hidden="true"
      className={`flex items-center justify-center bg-paper-deep/60 font-display text-7xl text-poster-ink/40 ${className}`}
    >
      {initials(poster.name)}
    </div>
  );
}

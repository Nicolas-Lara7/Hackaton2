import { btnSecondary } from './ui';

type Item = number | 'gap-start' | 'gap-end';

function buildItems(current: number, total: number): Item[] {
  if (total <= 7) return Array.from({ length: total }, (_, index) => index);
  const visible = new Set([0, total - 1, current - 1, current, current + 1]);
  const pages = [...visible].filter((page) => page >= 0 && page < total).sort((a, b) => a - b);
  const items: Item[] = [];
  pages.forEach((page, index) => {
    const previous = pages[index - 1];
    if (previous !== undefined && page - previous > 1) {
      items.push(previous < current ? 'gap-start' : 'gap-end');
    }
    items.push(page);
  });
  return items;
}

export function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;
  return (
    <nav aria-label="Paginación" className="flex flex-wrap items-center justify-center gap-2">
      <button
        type="button"
        className={btnSecondary}
        disabled={page <= 0}
        onClick={() => onChange(page - 1)}
      >
        Anterior
      </button>
      {buildItems(page, totalPages).map((item) =>
        typeof item === 'string' ? (
          <span key={item} aria-hidden="true" className="px-1 text-ink-soft">
            …
          </span>
        ) : (
          <button
            key={item}
            type="button"
            onClick={() => onChange(item)}
            aria-current={item === page ? 'page' : undefined}
            aria-label={`Ir a la página ${item + 1}`}
            className={`min-w-10 rounded-md border px-3 py-2 font-semibold ${
              item === page
                ? 'border-ink bg-ink text-chart'
                : 'border-ink/30 bg-white/70 hover:bg-white'
            }`}
          >
            {item + 1}
          </button>
        ),
      )}
      <button
        type="button"
        className={btnSecondary}
        disabled={page >= totalPages - 1}
        onClick={() => onChange(page + 1)}
      >
        Siguiente
      </button>
    </nav>
  );
}

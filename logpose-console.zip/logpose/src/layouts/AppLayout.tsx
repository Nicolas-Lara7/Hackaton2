import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { LogPoseMark, btnSecondary } from '../components/ui';

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-md px-3 py-1.5 font-semibold ${
    isActive ? 'bg-chart text-ink' : 'text-chart hover:bg-chart/15'
  }`;

export function AppLayout() {
  const { user, logout } = useAuth();
  return (
    <div className="min-h-screen">
      <header className="bg-ink text-chart">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <div className="flex items-center gap-2">
            <LogPoseMark className="h-8 w-8" />
            <span className="font-display text-2xl">Log Pose</span>
          </div>
          <nav aria-label="Principal" className="flex gap-1">
            <NavLink to="/" end className={linkClass}>
              Panel
            </NavLink>
            <NavLink to="/wanted" className={linkClass}>
              Se busca
            </NavLink>
          </nav>
          <div className="ml-auto flex items-center gap-3">
            <p className="text-sm leading-tight">
              <span className="block font-semibold">{user?.teamName}</span>
              {user?.teamCode && <span className="block text-chart/70">{user.teamCode}</span>}
            </p>
            <button type="button" className={`${btnSecondary} py-1.5!`} onClick={logout}>
              Cerrar sesión
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}

import { Outlet, ScrollRestoration } from 'react-router-dom';
import { AuthProvider } from '../auth/AuthContext';

export function RootLayout() {
  return (
    <AuthProvider>
      <Outlet />
      <ScrollRestoration />
    </AuthProvider>
  );
}

import type { FruitFilter, WantedStatus } from '../types'

export function formatBerries(amount: number): string {
  return `฿ ${new Intl.NumberFormat('es-PE').format(amount)}`
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('es-PE', { dateStyle: 'medium', timeStyle: 'short' })
}

export const STATUS_LABELS: Record<WantedStatus, string> = {
  AT_LARGE: 'Prófugo',
  CAPTURED: 'Capturado',
  MISSING: 'Desaparecido',
}

export const FRUIT_LABELS: Record<FruitFilter, string> = {
  PARAMECIA: 'Paramecia',
  ZOAN: 'Zoan',
  LOGIA: 'Logia',
  NONE: 'Sin fruta',
}

export const STATUS_COLORS: Record<WantedStatus, string> = {
  AT_LARGE: 'bg-red-500/20 text-red-300',
  CAPTURED: 'bg-emerald-500/20 text-emerald-300',
  MISSING: 'bg-slate-500/20 text-slate-300',
}

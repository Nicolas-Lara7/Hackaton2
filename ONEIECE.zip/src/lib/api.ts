import type { ApiErrorBody, FieldError } from '../types'

// La URL base sale de la variable de entorno (nunca escrita en el código).
const BASE_URL = import.meta.env.VITE_API_BASE_URL

const TOKEN_KEY = 'logpose.token'

export const tokenStorage = {
  get: (): string | null => localStorage.getItem(TOKEN_KEY),
  set: (token: string): void => localStorage.setItem(TOKEN_KEY, token),
  clear: (): void => localStorage.removeItem(TOKEN_KEY),
}

// Error propio con el formato que devuelve el backend.
export class ApiError extends Error {
  status: number
  code: string
  details: FieldError[]

  constructor(status: number, code: string, message: string, details: FieldError[] = []) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.details = details
  }
}

// Cuando el servidor responde 401, avisamos al AuthContext para cerrar la sesión.
let unauthorizedHandler: (() => void) | null = null

export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler
}

export function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === 'AbortError'
}

export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error
  return new ApiError(0, 'UNKNOWN', 'Ocurrió un error inesperado')
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH'
  body?: unknown
  signal?: AbortSignal
  auth?: boolean
}

export async function apiFetch<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, signal, auth = true } = options

  const headers: Record<string, string> = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  const token = tokenStorage.get()
  if (auth && token) headers.Authorization = `Bearer ${token}`

  let response: Response
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    })
  } catch (error) {
    if (isAbortError(error)) throw error
    throw new ApiError(0, 'NETWORK_ERROR', 'No se pudo conectar con el servidor')
  }

  if (!response.ok) {
    let errorBody: Partial<ApiErrorBody> = {}
    try {
      errorBody = (await response.json()) as Partial<ApiErrorBody>
    } catch {
      // la respuesta no trae JSON
    }

    if (response.status === 401 && auth) unauthorizedHandler?.()

    throw new ApiError(
      response.status,
      errorBody.code ?? 'HTTP_ERROR',
      errorBody.message ?? `Error ${response.status}`,
      errorBody.details ?? [],
    )
  }

  return (await response.json()) as T
}

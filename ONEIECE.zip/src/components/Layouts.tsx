import { NavLink, Outlet, ScrollRestoration, useNavigate } from 'react-router'
import { useAuth } from '../auth/AuthContext'

// Layout raíz: restaura el scroll al usar atrás/adelante.
export function RootLayout() {
  return (
    <>
      <ScrollRestoration />
      <Outlet />
    </>
  )
}

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `rounded px-3 py-1.5 text-sm font-medium ${isActive ? 'bg-amber-400 text-slate-900' : 'text-slate-300 hover:bg-slate-800'}`

// Layout de la app privada: barra superior + contenido.
export function AppLayout() {
  const { team, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login', { replace: true })
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-800 bg-slate-900/80">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <span className="mr-4 font-bold text-amber-400">🧭 Log Pose Console</span>
          <nav className="flex gap-2">
            <NavLink to="/" end className={linkClass}>
              Dashboard
            </NavLink>
            <NavLink to="/wanted" className={linkClass}>
              Se Busca
            </NavLink>
          </nav>
          <div className="ml-auto flex items-center gap-3 text-sm">
            {team && (
              <span className="text-slate-400">
                {team.name} · <span className="font-mono">{team.code}</span>
              </span>
            )}
            <button
              type="button"
              onClick={handleLogout}
              className="rounded border border-slate-600 px-3 py-1.5 hover:bg-slate-800"
            >
              Cerrar sesión
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Outlet />
      </main>
    </div>
  )
}
